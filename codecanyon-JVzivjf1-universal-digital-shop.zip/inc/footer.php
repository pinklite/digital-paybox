<?php
if (!defined('UAP_CORE')) die('What are you doing here?');
?>
				</div>
			</div>
			<footer>
				<?php echo get_bloginfo('name').', '.esc_html__('version', 'hap').' '.UAP_CORE.'. '.esc_html__('Copyright', 'hap').' © '.date('Y').', Halfdata Team.'; ?>
			</footer>
		</div>
	</div>
</body>
</html>
