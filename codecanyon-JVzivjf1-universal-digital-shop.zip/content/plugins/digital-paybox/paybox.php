<?php
/*
Plugin Name: Digital Paybox
Plugin URI: https://halfdata.com/andromeda/digital-paybox.html
Description: Sell digital content. The only actions you have do are to upload files and insert shortcode like <code>[paybox id="X"]</code> into your posts or pages.
Version: 4.35
Author: Halfdata, Inc.
Author URI: https://codecanyon.net/user/halfdata?ref=halfdata
*/
define('PAYBOX_RECORDS_PER_PAGE', '20');
define('PAYBOX_VERSION', 4.35);
define('PAYBOX_UPLOADS_DIR', 'paybox');
register_activation_hook(__FILE__, array("paybox_class", "install"));
register_deactivation_hook(__FILE__, array("paybox_class", "uninstall"));

class paybox_class {
	var $options;
	var $error;
	var $info;
	var $currency_list;
	
	var $paypal_currency_list = array("USD", "AUD", "BRL", "CAD", "CHF", "CZK", "DKK", "EUR", "GBP", "HKD", "HUF", "ILS", "JPY", "MXN", "MYR", "NOK", "NZD", "PHP", "PLN", "RUB", "SEK", "SGD", "THB", "TRY", "TWD");
	var $payza_currency_list = array("AUD", "BGN", "CAD", "CHF", "CZK", "DKK", "EEK", "EUR", "GBP", "HKD", "HUF", "INR", "LTL", "MYR", "MKD", "NOK", "NZD", "PLN", "RON", "SEK", "SGD", "USD", "ZAR");
	var $skrill_currency_list = array("EUR","TWD","USD","THB","GBP","CZK","HKD","HUF","SGD","SKK","JPY","EEK","CAD","BGN","AUD","PLN","CHF","ISK","DKK","INR","SEK","LVL","NOK","KRW","ILS","ZAR","MYR","RON","NZD","HRK","TRY","LTL","AED","JOD","MAD","OMR","QAR","RSD","SAR","TND");
	var $interkassa_currency_list = array("USD", "EUR", "RUB", "UAH");
	var $bitpay_currency_list = array("USD", "EUR", "GBP", "AUD", "CAD", "CHF", "CNY", "RUB", "DKK", "HKD", "PLN", "SGD", "THB", "BTC");
	var $stripe_currency_list = array("AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BGN", "BIF", "BMD", "BND", "BOB", "BRL", "BSD", "BWP", "BZD", "CAD", "CDF", "CHF", "CLP", "CNY", "COP", "CRC", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EEK", "EGP", "ETB", "EUR", "FJD", "FKP", "GBP", "GEL", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR", "ILS", "INR", "ISK", "JMD", "JPY", "KES", "KGS", "KHR", "KMF", "KRW", "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LTL", "LVL", "MAD", "MDL", "MGA", "MKD", "MNT", "MOP", "MRO", "MUR", "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SEK", "SGD", "SHP", "SLL", "SOS", "SRD", "STD", "SVC", "SZL", "THB", "TJS", "TOP", "TRY", "TTD", "TWD", "TZS", "UAH", "UGX", "USD", "UYU", "UZS", "VND", "VUV", "WST", "XAF", "XCD", "XOF", "XPF", "YER", "ZAR", "ZMW");
	var $perfect_currency_list = array("USD", "EUR");
	var $blockchain_currency_list = array("BTC", "USD", "ISK", "HKD", "TWD", "CHF", "EUR", "DKK", "CLP", "CAD", "CNY", "THB", "AUD", "SGD", "KRW", "JPY", "PLN", "GBP", "SEK", "NZD", "BRL", "RUB");
	
	var $default_file_details = array(
		'title' => '',
		'intro' => '',
		'filename' => '',
		'uploaded' => '',
		'filename_original' => '',
		'price' => '',
		'currency' => 'USD',
		'available_copies' => 0,
		'fixed_price' => 0
	);
	
	function __construct() {
		if (function_exists('load_plugin_textdomain')) {
			load_plugin_textdomain('paybox', false, dirname(plugin_basename(__FILE__)).'/languages/');
		}
		$this->currency_list = array_unique(array_merge($this->paypal_currency_list, $this->payza_currency_list, $this->interkassa_currency_list, $this->blockchain_currency_list, $this->skrill_currency_list, $this->bitpay_currency_list, $this->stripe_currency_list, $this->perfect_currency_list));
		sort($this->currency_list);
		$this->currency_list = array_unique(array_merge(array("USD"), $this->currency_list));
		
		$this->options = array (
			"version" => PAYBOX_VERSION,
			"enable_paypal" => "off",
			"paypal_id" => "",
			"paypal_address" => "off",
			"enable_payza" => "off",
			"payza_id" => "",
			"payza_sandbox" => "off",
			"enable_interkassa" =>"off",
			"interkassa_checkout_id" => "",
			"interkassa_secret_key" => "",
			"enable_authnet" => "off",
			"authnet_login_id" => "",
			"authnet_transaction_key" => "",
			"authnet_signature_key" => "",
			"authnet_webhook_uid" => $this->random_string(9),
			"authnet_sandbox" => "off",
			"enable_skrill" => "off",
			"skrill_id" => "",
			"skrill_secret_word" => "",
			"enable_bitpay" => "off",
			"bitpay_key" => "",
			"bitpay_speed" => "medium",
			"enable_stripe" => "off",
			"stripe_public_key" => "",
			"stripe_secret_key" => "",
			"stripe_webhook_secret" => "",
			"stripe_webhook_uid" => $this->random_string(24),
			"enable_perfect" => "off",
			"perfect_account_id" => "",
			"perfect_payee_name" => "",
			"perfect_passphrase" => "",
			"enable_blockchain" => "off",
			"blockchain_api_key" => "",
			"blockchain_xpub" => "",
			"blockchain_secret" => "",
			"blockchain_confirmations" => 1,
			"xsendfile" => "off",
			"seller_email" => "alerts@".str_replace("www.", "", $_SERVER["SERVER_NAME"]),
			"from_name" => get_bloginfo("name"),
			"from_email" => "noreply@".str_replace("www.", "", $_SERVER["SERVER_NAME"]),
			"success_email_subject" => __('Product download details', 'paybox'),
			"success_email_body" => __('Dear {payer_name},', 'paybox').PHP_EOL.PHP_EOL.__('Thank you for your payment for {product_title}. Click the link below to download the product:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('Please remember that this link is valid for {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.get_bloginfo("name"),
			"failed_email_subject" => __('Payment was not completed', 'paybox'),
			"failed_email_body" => __('Dear {payer_name},', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that we have received your payment for {product_title}.', 'paybox').PHP_EOL.__('The payment status is currently: {payment_status}', 'paybox').PHP_EOL.__('Once the payment is completed and cleared, we will send the download details to you by e-mail.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.get_bloginfo("name"),
			"buynow_type" => "html",
			"buynow_image" => "",
			"link_lifetime" => "2",
			"gdpr_enable" => "on",
			"gdpr_title" => __('I agree with the {Terms & Conditions}', 'paybox'),
			"gdpr_error_label" => __('You must agree with the Terms & Conditions.', 'paybox'),
			"terms" => ""
		);

		if (!empty($_COOKIE["paybox_error"])) {
			$this->error = stripslashes($_COOKIE["paybox_error"]);
			setcookie("paybox_error", "", time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
		}
		if (!empty($_COOKIE["paybox_info"])) {
			$this->info = stripslashes($_COOKIE["paybox_info"]);
			setcookie("paybox_info", "", time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
		}

		$this->get_options();
		
		if (is_admin()) {
			$version = get_option('donationdownloads_version');
			if ($version && $version < 4.20) {
				add_action('admin_notices', array(&$this, 'admin_warning_reactivate'));
			}
			add_action('wpmu_new_blog', array(&$this, 'install_new_blog'), 10, 6);
			add_action('delete_blog', array(&$this, 'uninstall_blog'), 10, 2);
			add_action('admin_enqueue_scripts', array(&$this, 'admin_enqueue_scripts'));
			add_action('admin_menu', array(&$this, 'admin_menu'));
			add_action('admin_head', array(&$this, 'admin_head'));
			add_action('init', array(&$this, 'admin_request_handler'));
			add_action('wp_ajax_paybox-save-settings', array(&$this, "admin_save_settings"));
			add_action('wp_ajax_paybox-create-link', array(&$this, "admin_create_link"));
			add_action('wp_ajax_paybox-transaction-details', array(&$this, "admin_transaction_details"));
			add_action('wp_ajax_paybox_continue', array(&$this, "paybox_continue"));
			add_action('wp_ajax_nopriv_paybox_continue', array(&$this, "paybox_continue"));
			add_action('wp_ajax_paybox_sendlink', array(&$this, "paybox_sendlink"));
			add_action('wp_ajax_nopriv_paybox_sendlink', array(&$this, "paybox_sendlink"));
			add_action('wp_ajax_paybox_getbitpayurl', array(&$this, "paybox_getbitpayurl"));
			add_action('wp_ajax_nopriv_paybox_getbitpayurl', array(&$this, "paybox_getbitpayurl"));
			add_action('wp_ajax_paybox_getblockchainaddress', array(&$this, "paybox_getblockchainaddress"));
			add_action('wp_ajax_nopriv_paybox_getblockchainaddress', array(&$this, "paybox_getblockchainaddress"));
			add_action('wp_ajax_paybox-remote-init', array(&$this, "remote_init"));
			add_action('wp_ajax_nopriv_paybox-remote-init', array(&$this, "remote_init"));
			add_filter('wp_privacy_personal_data_exporters', array(&$this, 'personal_data_exporters'), 2);
			add_filter('wp_privacy_personal_data_erasers', array(&$this, 'personal_data_erasers'), 2);
		} else {
			add_action('wp_head', array(&$this, "front_header"));
			add_action('wp_footer', array(&$this, "front_footer"));
			add_shortcode('donation-downloads', array(&$this, "shortcode_handler"));
			add_shortcode('donationdownloads', array(&$this, "shortcode_handler"));
			add_shortcode('paybox', array(&$this, "shortcode_handler"));
		}
		add_action('init', array(&$this, "front_init"));
	}

	function admin_enqueue_scripts() {
		wp_enqueue_script("jquery");
		wp_enqueue_script('paybox', plugins_url('/js/admin.js', __FILE__), array(), PAYBOX_VERSION);
		wp_enqueue_style('paybox', plugins_url('/css/admin.css', __FILE__));
	}

	function front_enqueue_scripts() {
		wp_enqueue_script("jquery");
		wp_enqueue_script('paybox', plugins_url('/js/script.js', __FILE__), array(), PAYBOX_VERSION);
		wp_enqueue_style('paybox', plugins_url('/css/style.css', __FILE__), array(), PAYBOX_VERSION);
		if ($this->options['enable_stripe'] == 'on') wp_enqueue_script('stripe', 'https://js.stripe.com/v3/', array(), PAYBOX_VERSION, true);
	}

	function admin_head() {
		echo '<script>var paybox_ajax_handler = "'.admin_url('admin-ajax.php').'";</script>';
	}

	static function install($_networkwide = null) {
		global $wpdb;
		if (function_exists('is_multisite') && is_multisite()) {
			if ($_networkwide) {
				$old_blog = $wpdb->blogid;
				$blog_ids = $wpdb->get_col('SELECT blog_id FROM '.esc_sql($wpdb->blogs));
				foreach ($blog_ids as $blog_id) {
					switch_to_blog($blog_id);
					self::activate();
				}
				switch_to_blog($old_blog);
				return;
			}
		}
		self::activate();
	}

	function install_new_blog($_blog_id, $_user_id, $_domain, $_path, $_site_id, $_meta) {
		if (is_plugin_active_for_network(basename(dirname(__FILE__)).'/' ).basename(__FILE__)) {
			switch_to_blog($_blog_id);
			self::activate();
			restore_current_blog();
		}
	}

	static function activate () {
		global $wpdb;
		$table_name = $wpdb->prefix."dd_files";
		if($wpdb->get_var("SHOW TABLES LIKE '".$table_name."'") != $table_name) {
			$sql = "CREATE TABLE ".$table_name." (
				id int(11) NOT NULL auto_increment,
				title varchar(255) collate utf8_unicode_ci NOT NULL,
				intro text collate utf8_unicode_ci NOT NULL,
				filename varchar(255) collate utf8_unicode_ci NOT NULL,
				uploaded int(11) NOT NULL default '1',
				filename_original varchar(255) collate utf8_unicode_ci NOT NULL,
				price float NOT NULL,
				currency varchar(7) collate utf8_unicode_ci NOT NULL,
				available_copies int(11) NOT NULL default '0',
				fixed_price int(11) NOT NULL default '0',
				registered int(11) NOT NULL,
				deleted int(11) NOT NULL default '0',
				UNIQUE KEY  id (id)
			);";
			$wpdb->query($sql);
		}
		$table_name = $wpdb->prefix."dd_downloadlinks";
		if($wpdb->get_var("SHOW TABLES LIKE '".$table_name."'") != $table_name) {
			$sql = "CREATE TABLE ".$table_name." (
				id int(11) NOT NULL auto_increment,
				file_id int(11) NOT NULL,
				download_key varchar(255) collate utf8_unicode_ci NOT NULL,
				owner varchar(63) collate utf8_unicode_ci NOT NULL,
				source varchar(15) collate utf8_unicode_ci NOT NULL,
				created int(11) NOT NULL,
				deleted int(11) NOT NULL default '0',
				UNIQUE KEY  id (id)
			);";
			$wpdb->query($sql);
		}
		$table_name = $wpdb->prefix."dd_transactions";
		if($wpdb->get_var("SHOW TABLES LIKE '".$table_name."'") != $table_name) {
			$sql = "CREATE TABLE ".$table_name." (
				id int(11) NOT NULL auto_increment,
				file_id int(11) NOT NULL,
				payer_name varchar(255) collate utf8_unicode_ci NOT NULL,
				payer_email varchar(255) collate utf8_unicode_ci NOT NULL,
				gross float NOT NULL,
				currency varchar(15) collate utf8_unicode_ci NOT NULL,
				payment_status varchar(31) collate utf8_unicode_ci NOT NULL,
				transaction_type varchar(31) collate utf8_unicode_ci NOT NULL,
				txn_id varchar(255) collate utf8_unicode_ci NOT NULL default '',
				details text collate utf8_unicode_ci NOT NULL,
				created int(11) NOT NULL,
				deleted int(11) NOT NULL default '0',
				UNIQUE KEY  id (id)
			);";
			$wpdb->query($sql);
		}
		update_option('donationdownloads_version', PAYBOX_VERSION);
		$upload_dir = wp_upload_dir();
		if (!file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR)) {
			if (wp_mkdir_p($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR)) {
				if (!file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'index.html')) {
					file_put_contents($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'index.html', 'Silence is the gold!');
				}
			}
		}
		if (!file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files')) {
			if (wp_mkdir_p($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files')) {
				if (!file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'.htaccess')) {
					file_put_contents($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'.htaccess', 'deny from all');
				}
			}
		}
	}

	static function uninstall() {
		global $wpdb;
		if (function_exists('is_multisite') && is_multisite()) {
			$old_blog = $wpdb->blogid;
			$blog_ids = $wpdb->get_col('SELECT blog_id FROM '.esc_sql($wpdb->blogs));
			foreach ($blog_ids as $blog_id) {
				switch_to_blog($blog_id);
				self::deactivate(false);
			}
			switch_to_blog($old_blog);
		} else {
			self::deactivate(false);
		}
	}

	function uninstall_blog($_blog_id, $_drop) {
		if (is_plugin_active_for_network(basename(dirname(__FILE__)).'/'.basename(__FILE__)) && $_drop) {
			switch_to_blog($_blog_id);
			self::deactivate(true);
			restore_current_blog();
		}
	}
	
	static function deactivate($_force_delete = false) {
		global $wpdb;
		$clean_database = get_option('donationdownloads-clean-database', 'off');
		if ($clean_database == 'on' || $_force_delete) {
			$wpdb->query("DELETE FROM ".$wpdb->prefix."options WHERE option_name LIKE 'donationdownloads_%' AND option_name != 'donationdownloads-clean-database'");
			$wpdb->query("DROP TABLE IF EXISTS ".$wpdb->prefix."dd_files");
			$wpdb->query("DROP TABLE IF EXISTS ".$wpdb->prefix."dd_downloadlinks");
			$wpdb->query("DROP TABLE IF EXISTS ".$wpdb->prefix."dd_transactions");
		}
	}
	

	function get_options() {
		$exists = get_option('donationdownloads_version');
		if ($exists) {
			foreach ($this->options as $key => $value) {
				$this->options[$key] = get_option('donationdownloads_'.$key, $this->options[$key]);
			}
		}
		if ($this->options['blockchain_secret'] == '') $this->options['blockchain_secret'] = $this->random_string(16);
	}

	function update_options() {
		//if (current_user_can('manage_options')) {
			foreach ($this->options as $key => $value) {
				update_option('donationdownloads_'.$key, $value);
			}
		//}
	}

	function admin_menu() {
		add_menu_page(
			"Digital Paybox"
			, "Digital Paybox"
			, "add_users"
			, "paybox"
			, array(&$this, 'admin_files')
		);
		add_submenu_page(
			"paybox"
			, __('Files', 'paybox')
			, __('Files', 'paybox')
			, "add_users"
			, "paybox"
			, array(&$this, 'admin_files')
		);
		add_submenu_page(
			"paybox"
			, __('Add File', 'paybox')
			, __('Add File', 'paybox')
			, "add_users"
			, "paybox-add"
			, array(&$this, 'admin_add_file')
		);
		add_submenu_page(
			"paybox"
			, __('Download Links', 'paybox')
			, __('Download Links', 'paybox')
			, "add_users"
			, "paybox-links"
			, array(&$this, 'admin_links')
		);
		add_submenu_page(
			"paybox"
			, __('Add Link', 'paybox')
			, __('Add Link', 'paybox')
			, "add_users"
			, "paybox-add-link"
			, array(&$this, 'admin_add_link')
		);
		add_submenu_page(
			"paybox"
			, __('Transactions', 'paybox')
			, __('Transactions', 'paybox')
			, "add_users"
			, "paybox-transactions"
			, array(&$this, 'admin_transactions')
		);
		add_submenu_page(
			"paybox"
			, __('Settings', 'paybox')
			, __('Settings', 'paybox')
			, "add_users"
			, "paybox-settings"
			, array(&$this, 'admin_settings')
		);
		if (defined('UAP_CORE')) {
			add_submenu_page(
				"paybox"
				, __('How To Use', 'paybox')
				, __('How To Use', 'paybox')
				, "manage_options"
				, "paybox-using"
				, array(&$this, 'admin_using')
			);
		}
	}

	function admin_settings() {
		global $wpdb;
		$errors = array();
		echo '
		<div class="wrap paybox">
			<h2>'.__('Digital Paybox - Settings', 'paybox').'</h2>
			<form class="paybox-form" enctype="multipart/form-data" method="post" style="margin: 0px" action="'.admin_url('admin.php').'">
			<div class="postbox-container" style="width: 100%;">
				<div class="metabox-holder">
					<div class="meta-box-sortables ui-sortable">
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('General Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('E-mail for notifications', 'paybox').':</th>
										<td><input type="text" id="paybox_seller_email" name="paybox_seller_email" value="'.esc_html($this->options['seller_email']).'" class="widefat"><br /><em>'.__('Please enter e-mail address. All alerts about completed/failed payments are sent to this e-mail address.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Sender name', 'paybox').':</th>
										<td><input type="text" id="paybox_from_name" name="paybox_from_name" value="'.esc_html($this->options['from_name']).'" class="widefat"><br /><em>'.__('Please enter sender name. All messages to buyers are sent using this name as "FROM:" header value.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Sender e-mail', 'paybox').':</th>
										<td><input type="text" id="paybox_from_email" name="paybox_from_email" value="'.esc_html($this->options['from_email']).'" class="widefat"><br /><em>'.__('Please enter sender e-mail. All messages to buyers are sent using this e-mail as "FROM:" header value.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Successful payment e-mail subject', 'paybox').':</th>
										<td><input type="text" id="paybox_success_email_subject" name="paybox_success_email_subject" value="'.esc_html($this->options['success_email_subject']).'" class="widefat"><br /><em>'.__('In case of successful and cleared payment, your customers receive e-mail message about successful payment. This is subject field of the message.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Successful payment e-mail body', 'paybox').':</th>
										<td><textarea id="paybox_success_email_body" name="paybox_success_email_body" class="widefat" style="height: 120px;">'.esc_html($this->options['success_email_body']).'</textarea><br /><em>'.__('This e-mail message is sent to your customers in case of successful and cleared payment. You can use the following keywords: {payer_name}, {payer_email}, {product_title}, {product_amount}, {product_currency}, {download_link}, {download_link_lifetime}.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Failed payment e-mail subject', 'paybox').':</th>
										<td><input type="text" id="paybox_failed_email_subject" name="paybox_failed_email_subject" value="'.esc_html($this->options['failed_email_subject']).'" class="widefat"><br /><em>'.__('In case of pending, non-cleared or fake payment, your customers receive e-mail message about that. This is subject field of the message.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Failed payment e-mail body', 'paybox').':</th>
										<td><textarea id="paybox_failed_email_body" name="paybox_failed_email_body" class="widefat" style="height: 120px;">'.esc_html($this->options['failed_email_body']).'</textarea><br /><em>'.__('This e-mail message is sent to your customers in case of pending, non-cleared or fake payment. You can use the following keywords: {payer_name}, {payer_email}, {product_title}, {product_payment}, {product_currency}, {payment_status}.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Download link lifetime', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_link_lifetime" name="paybox_link_lifetime" value="'.esc_html($this->options['link_lifetime']).'" style="width: 100px; text-align: right;"> <span style="line-height: 32px;">'.__('days', 'paybox').'</span>
											<br /><em>'.__('Please enter period of download link validity.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('GDPR-compatibility', 'paybox').':</th>
										<td>
											<input type="checkbox" id="paybox_gdpr_enable" name="paybox_gdpr_enable" '.($this->options['gdpr_enable'] == "on" ? 'checked="checked"' : '').'" onclick="paybox_switch_gdpr();"> '.__('Enable checkbox to agree with the Terms & Conditions', 'paybox').'
											<br /><em>'.__('Please tick checkbox if you want to add checkbox to subscription form.', 'paybox').'</em>
										</td>
									</tr>
									<tr class="paybox-gdpr-depend"'.($this->options['gdpr_enable'] == "on" ? ' style="display:table-row;"' : '').'>
										<th>'.__('Checkbox label', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_gdpr_title" name="paybox_gdpr_title" value="'.esc_html($this->options['gdpr_title']).'" class="widefat">
											<br /><em>'.__('Enter the label for GDPR checkbox. Wrap your keyword with "{" and "}" to link it with Terms & Conditions box. HTML allowed.', 'paybox').'</em>
										</td>
									</tr>
									<tr class="paybox-gdpr-depend"'.($this->options['gdpr_enable'] == "on" ? ' style="display:table-row;"' : '').'>
										<th>'.__('Terms & Conditions', 'paybox').':</th>
										<td><textarea id="paybox_terms" name="paybox_terms" class="widefat" style="height: 120px;">'.esc_html($this->options['terms']).'</textarea><br /><em>'.__('Your customers must be agree with Terms & Conditions before paying. Leave this field blank if you do not need Terms & Conditions box to be shown.', 'paybox').'</em></td>
									</tr>
									<tr class="paybox-gdpr-depend"'.($this->options['gdpr_enable'] == "on" ? ' style="display:table-row;"' : '').'>
										<th>'.__('Error label', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_gdpr_error_label" name="paybox_gdpr_error_label" value="'.esc_html($this->options['gdpr_error_label']).'" class="widefat">
											<br /><em>'.__('Enter the error label for GDPR checkbox. It appears when user forgot to tick GDPR checkbox.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Enable X-Sendfile', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_xsendfile" name="paybox_xsendfile" '.($this->options['xsendfile'] == "on" ? 'checked="checked"' : '').'> '.__('Download files through X-Sendfile module','paybox').'<br /><em>'.__('Use this option to enable X-SendFile mode to download huge files. Please contact your hosting provider to make sure that <a href="https://tn123.org/mod_xsendfile/" target="_blank"><strong>mod_xsendfile</strong></a> module installed on your server. Do not activate this option if <strong>mod_xsendfile</strong> module is not installed.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('PayPal Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_paypal" name="paybox_enable_paypal" '.($this->options['enable_paypal'] == "on" ? 'checked="checked"' : '').'"> '.__('Accept payments via PayPal', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via PayPal.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('PayPal ID', 'paybox').':</th>
										<td><input type="text" id="paybox_paypal_id" name="paybox_paypal_id" value="'.esc_html($this->options['paypal_id']).'" class="widefat"><br /><em>'.__('Please enter valid PayPal e-mail or <a href="https://www.paypal.com/webapps/customerprofile/summary.view" traget="_blank">Merchant ID</a>, all payments are sent to this account.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Enable shipping address', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_paypal_address" name="paybox_paypal_address" '.($this->options['paypal_address'] == "on" ? 'checked="checked"' : '').'> '.__('Include shipping address into transaction', 'paybox').'<br /><em>'.__('Activate this option if you plan to send physical copy of your downloadable product (CD, DVD, etc.). Shipping address is taken from payer PayPal account. You can view shipping address at transaction details page.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Payza Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr><th colspan="2">'.__('IMPORTANT! Set "IPN Status" as "Enabled" on <a target="_blank" href="https://secure.payza.com/ManageIPN.aspx">Payza IPN Setup</a> page.', 'paybox').'</th></tr>
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_payza" name="paybox_enable_payza" '.($this->options['enable_payza'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via Payza', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via Payza.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Payza ID', 'paybox').':</th>
										<td><input type="text" id="paybox_payza_id" name="paybox_payza_id" value="'.esc_html($this->options['payza_id']).'" class="widefat"'.'><br /><em>'.__('Please enter valid Payza e-mail, all payments are sent to this account.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Sandbox mode', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_payza_sandbox" name="paybox_payza_sandbox" '.($this->options['payza_sandbox'] == "on" ? 'checked="checked"' : '').'> '.__('Enable Payza sandbox mode', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to test Payza service.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Skrill (Moneybookers) Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_skrill" name="paybox_enable_skrill" '.($this->options['enable_skrill'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via Skrill (Moneybookers)', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via Skrill (Moneybookers).', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Skrill ID', 'paybox').':</th>
										<td><input type="text" id="paybox_skrill_id" name="paybox_skrill_id" value="'.esc_html($this->options['skrill_id']).'" class="widefat"><br /><em>'.__('Please enter valid Skrill (Moneybookers) e-mail, all payments are sent to this account.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Secret Word', 'paybox').':</th>
										<td><input type="text" id="paybox_skrill_secret_word" name="paybox_skrill_secret_word" value="'.esc_html($this->options['skrill_secret_word']).'" class="widefat"><br /><em>'.__('Please enter valid Skrill Secret Word. You must set it on <a target="_blank" href="https://www.moneybookers.com/app/profile.pl?view=merchant_tools">merchant tools</a> page.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('InterKassa 2.0 Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr><th colspan="2">'.__('IMPORTANT! Register your checkout on <a target="_blank" href="http://new.interkassa.com/account/checkout">My Checkouts</a> page.', 'paybox').'</th></tr>
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_interkassa" name="paybox_enable_interkassa" '.($this->options['enable_interkassa'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via InterKassa', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via InterKassa.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Checkout ID', 'paybox').':</th>
										<td><input type="text" id="paybox_interkassa_checkout_id" name="paybox_interkassa_checkout_id" value="'.esc_html($this->options['interkassa_checkout_id']).'" class="widefat"><br /><em>'.__('Please enter valid InterKassa Checkout ID. Ex.: 5294dadebf4efc4f543309eb', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Secret/Sign Key', 'paybox').':</th>
										<td><input type="text" id="paybox_interkassa_secret_key" name="paybox_interkassa_secret_key" value="'.esc_html($this->options['interkassa_secret_key']).'" class="widefat"><br /><em>'.__('Please enter Secret/Sign Key. You can get it on <a target="_blank" href="http://new.interkassa.com/account/checkout">checkout settings</a> page.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Authorize.Net Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_authnet" name="paybox_enable_authnet" '.($this->options['enable_authnet'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via Authorize.Net', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via Authorize.Net.', 'paybox').'</em></td>
									</tr>
									<tr><th></th><td>
										<strong>'.esc_html__('Important! Make sure that you created webhook with the following URL for event "Payment Events" in your Authorize.Net account (Account > Settings > Business Settings > Notification Settings > Webhooks).', 'paybox').'</strong>
										<input type="text" readonly="readonly" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php')) : esc_html(get_bloginfo('url').'/paybox-authnet-ipn-handler/')).'" onclick="this.focus();this.select();" class="widefat" />
									</td></tr>
									<tr>
										<th>'.__('API Login ID', 'paybox').':</th>
										<td><input type="text" id="paybox_authnet_login_id" name="paybox_authnet_login_id" value="'.esc_html($this->options['authnet_login_id']).'" class="widefat"><br /><em>'.__('Please enter valid Authorize.Net login.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Transaction Key', 'paybox').':</th>
										<td><input type="text" id="paybox_authnet_transaction_key" name="paybox_authnet_transaction_key" value="'.esc_html($this->options['authnet_transaction_key']).'" class="widefat"><br /><em>'.__('Please enter Transaction Key. If you do not know Transaction Key, go to your Authorize.Net account settings and click "API Credentials & Keys".', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Signature Key', 'paybox').':</th>
										<td><input type="text" id="paybox_authnet_signature_key" name="paybox_authnet_signature_key" value="'.esc_html($this->options['authnet_signature_key']).'" class="widefat"><br /><em>'.__('Please enter Signature Key. If you do not know Signature Key, go to your Authorize.Net account settings and click "API Credentials & Keys".', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Sandbox mode', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_authnet_sandbox" name="paybox_authnet_sandbox" '.($this->options['authnet_sandbox'] == "on" ? 'checked="checked"' : '').'> '.__('Enable Authorize.Net sandbox mode', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to test Authorize.Net service.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('BitPay Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_bitpay" name="paybox_enable_bitpay" '.($this->options['enable_bitpay'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via BitPay', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via BitPay.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('API Key', 'paybox').':</th>
										<td><input type="text" id="paybox_bitpay_key" name="paybox_bitpay_key" value="'.esc_html($this->options['bitpay_key']).'" class="widefat"><br /><em>'.__('Please enter valid API Key. You can get this parameter <a href="https://bitpay.com/api-keys" target="_blank">here</a>.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Transaction speed', 'paybox').':</th>
										<td>
											<select id="paybox_bitpay_speed" name="paybox_bitpay_speed">
												<option value="high"'.($this->options['bitpay_speed'] == 'high' ? ' selected="selected"' : '').'>'.__('Immediate', 'paybox').'</option>
												<option value="medium"'.($this->options['bitpay_speed'] == 'medium' ? ' selected="selected"' : '').'>'.__('After 1 block confirmation', 'paybox').'</option>
												<option value="low"'.($this->options['bitpay_speed'] == 'low' ? ' selected="selected"' : '').'>'.__('After 6 block confirmations', 'paybox').'</option>
											</select>
											<br /><em>'.__('Please set how fast an invoice is considered to be "confirmed".', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Blockchain.info Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_blockchain" name="paybox_enable_blockchain" '.($this->options['enable_blockchain'] == "on" ? 'checked="checked"' : '').'> '.__('Accept bitcoins (through Blockchain.info API)', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept bitcoins (using Blockchain.info API).', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Receive Payments API Key', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_blockchain_api_key" name="paybox_blockchain_api_key" value="'.esc_html($this->options['blockchain_api_key']).'" class="widefat">
											<br /><em>'.__('Please apply for an API key at <a href="https://api.blockchain.info/v2/apikey/request/" target="_blank">https://api.blockchain.info/v2/apikey/request/</a>. This API key is only for our Receive Payments API.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('xPub', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_blockchain_xpub" name="paybox_blockchain_xpub" value="'.esc_html($this->options['blockchain_xpub']).'" class="widefat">
											<br /><em>'.__('Please put Extended Public Key (xPub). This parameter is located on your <a href="https://blockchain.info/wallet/#/settings/addresses" target="_blank">Settings</a> page (click Manage > More Options > Show xPub).', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Secret', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_blockchain_secret" name="paybox_blockchain_secret" value="'.esc_html($this->options['blockchain_secret']).'" class="widefat">
											<br /><em>'.__('Please enter random alphanumeric string.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Confirmations', 'paybox').':</th>
										<td>
											<select id="paybox_blockchain_confirmations" name="paybox_blockchain_confirmations">';
		for ($i=0; $i<7; $i++) {
			echo '
												<option value="'.$i.'"'.($this->options['blockchain_confirmations'] == $i ? ' selected="selected"' : '').'>'.$i.'</option>';
		}
		echo '									
											</select>
											<br /><em>'.__('Please set the number of confirmations of transaction.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('PerfectMoney Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td>
											<input type="checkbox" id="paybox_enable_perfect" name="paybox_enable_perfect" '.($this->options['enable_perfect'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via PerfectMoney', 'paybox').'
											<br /><em>'.__('Please tick checkbox if you would like to accept payments via Perfect Money.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Payee Account', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_perfect_account_id" name="paybox_perfect_account_id" value="'.esc_html($this->options['perfect_account_id']).'" class="widefat">
											<br /><em>'.__('The merchant PerfectMoney account to which the payment is to be made.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Payee Name', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_perfect_payee_name" name="paybox_perfect_payee_name" value="'.esc_html($this->options['perfect_payee_name']).'" class="widefat">
											<br /><em>'.__('The name the merchant wishes to have displayed as the Payee on the PerfectMoney payment form.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Alternate Passphrase', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_perfect_passphrase" name="paybox_perfect_passphrase" value="'.esc_html($this->options['perfect_passphrase']).'" class="widefat">
											<br /><em>'.__('Please enter valid Alternate Passphrase. You can get this parameter <a href="https://perfectmoney.is/settings.html" target="_blank">here</a>.', 'paybox').'</em>
										</td>
									</tr>
								</table>
							</div>
						</div>
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Stripe Settings', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Enable', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_enable_stripe" name="paybox_enable_stripe" '.($this->options['enable_stripe'] == "on" ? 'checked="checked"' : '').'> '.__('Accept payments via Stripe', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to accept payments via Stripe.', 'paybox').'</em></td>
									</tr>
									<tr><th></th><td>
										<strong>'.sprintf(esc_html__('Important! Make sure that you created webhook with the following URL for event "checkout.session.completed" in your %sStripe Dashboard%s.', 'paybox'), '<a href="https://dashboard.stripe.com/account/webhooks" target="_blank">', '</a>').'</strong>
										<input type="text" readonly="readonly" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-ipn=stripe') : esc_html(get_bloginfo('url').'/?paybox-ipn=stripe')).'" onclick="this.focus();this.select();" class="widefat" />
									</td></tr>
									<tr>
										<th>'.__('Publishable Key', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_stripe_public_key" name="paybox_stripe_public_key" value="'.esc_html($this->options['stripe_public_key']).'" class="widefat">
											<br /><em>'.sprintf(esc_html__('Please enter valid Publishable Key. Find it on %sAPI Keys%s page.', 'paybox'), '<a href="https://dashboard.stripe.com/account/apikeys" target="_blank">', '</a>').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Secret Key', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_stripe_secret_key" name="paybox_stripe_secret_key" value="'.esc_html($this->options['stripe_secret_key']).'" class="widefat">
											<br /><em>'.sprintf(esc_html__('Please enter valid Secret Key. Find it on %sAPI Keys%s page.', 'paybox'), '<a href="https://dashboard.stripe.com/account/apikeys" target="_blank">', '</a>').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Signing Secret', 'paybox').':</th>
										<td>
											<input type="text" id="paybox_stripe_webhook_secret" name="paybox_stripe_webhook_secret" value="'.esc_html($this->options['stripe_webhook_secret']).'" class="widefat">
											<br /><em>'.sprintf(esc_html__('Find it on %sWebhooks%s page. Click webhook that you created earlier, and find "Signing secret" parameter.', 'paybox'), '<a href="https://dashboard.stripe.com/account/webhooks" target="_blank">', '</a>').'</em>
										</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
				<hr>
				<div class="paybox-button-container">
					<input type="hidden" name="action" value="paybox-save-settings" />
					<input type="hidden" name="paybox_version" value="'.PAYBOX_VERSION.'" />
					<a class="paybox-button" onclick="return paybox_save_settings(this);"><i class="paybox-fa paybox-fa-ok"></i><label>Save Settings</label></a>
				</div>
				<div class="paybox-message"></div>
			</div>
			</form>
			<div id="paybox-global-message"></div>
		</div>';
	}

	function admin_save_settings() {
		global $wpdb;
		if (current_user_can('manage_options')) {
			foreach ($this->options as $key => $value) {
				if (isset($_POST['paybox_'.$key])) {
					$this->options[$key] = stripslashes($_POST['paybox_'.$key]);
				}
			}
			if (isset($_POST["paybox_enable_paypal"])) $this->options['enable_paypal'] = "on";
			else $this->options['enable_paypal'] = "off";
			if (isset($_POST["paybox_enable_perfect"])) $this->options['enable_perfect'] = "on";
			else $this->options['enable_perfect'] = "off";
			if (isset($_POST["paybox_enable_payza"])) $this->options['enable_payza'] = "on";
			else $this->options['enable_payza'] = "off";
			if (isset($_POST["paybox_payza_sandbox"])) $this->options['payza_sandbox'] = "on";
			else $this->options['payza_sandbox'] = "off";
			if (isset($_POST["paybox_enable_skrill"])) $this->options['enable_skrill'] = "on";
			else $this->options['enable_skrill'] = "off";
			if (isset($_POST["paybox_enable_interkassa"])) $this->options['enable_interkassa'] = "on";
			else $this->options['enable_interkassa'] = "off";
			if (isset($_POST["paybox_paypal_address"])) $this->options['paypal_address'] = "on";
			else $this->options['paypal_address'] = "off";
			if (isset($_POST["paybox_enable_authnet"])) $this->options['enable_authnet'] = "on";
			else $this->options['enable_authnet'] = "off";
			if (isset($_POST["paybox_authnet_sandbox"])) $this->options['authnet_sandbox'] = "on";
			else $this->options['authnet_sandbox'] = "off";
			if (isset($_POST["paybox_enable_bitpay"])) $this->options['enable_bitpay'] = "on";
			else $this->options['enable_bitpay'] = "off";
			if (isset($_POST["paybox_enable_stripe"])) $this->options['enable_stripe'] = "on";
			else $this->options['enable_stripe'] = "off";
			if (isset($_POST["paybox_enable_blockchain"])) $this->options['enable_blockchain'] = "on";
			else $this->options['enable_blockchain'] = "off";
			if (isset($_POST["paybox_xsendfile"])) $this->options['xsendfile'] = "on";
			else $this->options['xsendfile'] = "off";
			if (isset($_POST["paybox_gdpr_enable"])) $this->options['gdpr_enable'] = "on";
			else $this->options['gdpr_enable'] = "off";

			$errors = array();
			//if ($this->options['enable_payza'] != "on" && $this->options['enable_paypal'] != "on" && $this->options['enable_interkassa'] != "on" && $this->options['enable_authnet'] != "on" && $this->options['enable_skrill'] != "on" && $this->options['enable_bitpay'] != "on" && $this->options['enable_stripe'] != "on" && $this->options['enable_perfect'] != "on") $errors[] = __('Select at least one payment method', 'paybox');
			if ($this->options['enable_paypal'] == "on") {
				if ((!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $this->options['paypal_id']) && !preg_match("/^([A-Z0-9]+)$/i", $this->options['paypal_id'])) || strlen($this->options['paypal_id']) == 0) $errors[] = __('PayPal ID must be valid e-mail address or Merchant ID', 'paybox');
			}
			if ($this->options['enable_payza'] == "on") {
				if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $this->options['payza_id']) || strlen($this->options['payza_id']) == 0) $errors[] = __('Payza ID must be valid e-mail address', 'paybox');
			}
			if ($this->options['enable_interkassa'] == "on") {
				if (strlen($this->options['interkassa_checkout_id']) < 3) $errors[] = __('InterKassa Checkout ID is required', 'paybox');
				if (strlen($this->options['interkassa_secret_key']) < 3) $errors[] = __('InterKassa Secret Key is required', 'paybox');
			}
			if ($this->options['enable_authnet'] == "on") {
				if (strlen($this->options['authnet_login_id']) < 3) $errors[] = __('Authorize.Net API Login ID is required', 'paybox');
				if (strlen($this->options['authnet_transaction_key']) < 1) $errors[] = __('Authorize.Net Transaction Key is required', 'paybox');
				if (strlen($this->options['authnet_signature_key']) < 1) $errors[] = __('Authorize.Net Signature Key is required', 'paybox');
			}
			if ($this->options['enable_skrill'] == "on") {
				if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $this->options['skrill_id']) || strlen($this->options['skrill_id']) == 0) $errors[] = __('Skrill ID must be valid e-mail address', 'paybox');
				if (strlen($this->options['skrill_secret_word']) < 1) $errors[] = __('Skrill Secret Word is required', 'paybox');
			}
			if ($this->options['enable_bitpay'] == "on") {
				if (strlen($this->options['bitpay_key']) < 1) $errors[] = __('BitPay API Key is required', 'paybox');
			}
			if ($this->options['enable_stripe'] == "on") {
				if (strlen($this->options['stripe_public_key']) < 1) $errors[] = __('Stripe Publishable Key is required.', 'paybox');
				if (strlen($this->options['stripe_secret_key']) < 1) $errors[] = __('Stripe Secret Key is required.', 'paybox');
				if (strlen($this->options['stripe_webhook_secret']) < 1) $errors[] = __('Stripe Signing Secret is required.', 'paybox');
			}
			if ($this->options['enable_perfect'] == "on") {
				if (strlen($this->options['perfect_account_id']) < 1) $errors[] = __('Perfect Money Payee Account is required', 'paybox');
				if (strlen($this->options['perfect_payee_name']) < 1) $errors[] = __('Perfect Money Payee Name is required', 'paybox');
				if (strlen($this->options['perfect_passphrase']) < 1) $errors[] = __('Perfect Money Alternate Passphrase is required', 'paybox');
			}
			if ($this->options['enable_blockchain'] == "on") {
				if (strlen($this->options['blockchain_api_key']) < 5) $errors[] =  __('Blockchain Receive Payment API Key is invalid', 'paybox');
				if (strlen($this->options['blockchain_xpub']) < 5) $errors[] =  __('Blockchain Extended Public Key (xPub) is invalid', 'paybox');
				if (strlen($this->options['blockchain_secret']) < 12) $errors[] =  __('Bitcoin Secret is too short', 'paybox');
			}
			if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $this->options['seller_email']) || strlen($this->options['seller_email']) == 0) $errors[] = __('E-mail for notifications must be valid e-mail address', 'paybox');
			if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $this->options['from_email']) || strlen($this->options['from_email']) == 0) $errors[] = __('Sender e-mail must be valid e-mail address', 'paybox');
			if (strlen($this->options['from_name']) < 3) $errors[] = __('Sender name is too short', 'paybox');
			if (strlen($this->options['success_email_subject']) < 3) $errors[] = __('Successful payment e-mail subject must contain at least 3 characters', 'paybox');
			else if (strlen($this->options['success_email_subject']) > 64) $errors[] = __('Successful payment e-mail subject must contain maximum 64 characters', 'paybox');
			if (strlen($this->options['success_email_body']) < 3) $errors[] = __('Successful payment e-mail body must contain at least 3 characters', 'paybox');
			if (strlen($this->options['failed_email_subject']) < 3) $errors[] = __('Failed payment e-mail subject must contain at least 3 characters', 'paybox');
			else if (strlen($this->options['failed_email_subject']) > 64) $errors[] = __('Failed payment e-mail subject must contain maximum 64 characters', 'paybox');
			if (strlen($this->options['failed_email_body']) < 3) $errors[] = __('Failed payment e-mail body must contain at least 3 characters', 'paybox');
			if (intval($this->options['link_lifetime']) != $this->options['link_lifetime'] || intval($this->options['link_lifetime']) < 1 || intval($this->options['link_lifetime']) > 365) $errors[] = __('Download link lifetime must be valid integer value in range [1...365]', 'paybox');
			
			if (!empty($errors)) {
				$return_object = array();
				$return_object['status'] = 'ERROR';
				$return_object['message'] = __('Attention! Please correct errors and try again.', 'paybox').'<ul><li>'.implode('</li><li>', $errors).'</li></ul>';
				echo json_encode($return_object);
				exit;
			}
			
			$this->update_options();
			$return_object = array();
			$return_object['status'] = 'OK';
			$return_object['message'] = __('Settings successfully <strong>saved</strong>.', 'paybox');
			echo json_encode($return_object);
			exit;
		}
	}

	function admin_files() {
		global $wpdb;

		if (isset($_GET["s"])) $search_query = trim(stripslashes($_GET["s"]));
		else $search_query = "";
		
		$tmp = $wpdb->get_row("SELECT COUNT(*) AS total FROM ".$wpdb->prefix."dd_files WHERE deleted = '0'".((strlen($search_query) > 0) ? "AND (filename_original LIKE '%".addslashes($search_query)."%' OR title LIKE '%".addslashes($search_query)."%')" : ""), ARRAY_A);
		$total = $tmp["total"];
		$totalpages = ceil($total/PAYBOX_RECORDS_PER_PAGE);
		if ($totalpages == 0) $totalpages = 1;
		if (isset($_GET["p"])) $page = intval($_GET["p"]);
		else $page = 1;
		if ($page < 1 || $page > $totalpages) $page = 1;
		$switcher = $this->page_switcher(admin_url('admin.php').'?page=paybox'.((strlen($search_query) > 0) ? "&s=".rawurlencode($search_query) : ""), $page, $totalpages);

		$sql = "SELECT * FROM ".$wpdb->prefix."dd_files WHERE deleted = '0'".((strlen($search_query) > 0) ? " AND (filename_original LIKE '%".addslashes($search_query)."%' OR title LIKE '%".addslashes($search_query)."%')" : "")." ORDER BY registered DESC LIMIT ".(($page-1)*PAYBOX_RECORDS_PER_PAGE).", ".PAYBOX_RECORDS_PER_PAGE;
		$rows = $wpdb->get_results($sql, ARRAY_A);
		if (!empty($this->error)) $message = "<div class='error'><p>".$this->error."</p></div>";
		else if (!empty($this->info)) $message = "<div class='updated'><p>".$this->info."</p></div>";
		else $message = '';

		echo '
			<div class="wrap admin_paybox_wrap">
				<h2>'.__('Digital Paybox - Files', 'paybox').'</h2>
				'.$message.'
				<form action="'.admin_url('admin.php').'" method="get" class="uap-filter-form paybox-filter-form">
				<input type="hidden" name="page" value="paybox" />
				<label>'.__('Search:', 'paybox').'</label>
				<input type="text" name="s" value="'.esc_html($search_query).'" style="width: 200px;" class="form-control">
				<input type="submit" class="button-secondary action" value="'.__('Search', 'paybox').'" />
				'.((strlen($search_query) > 0) ? '<input type="button" class="button-secondary action" value="'.__('Reset search results', 'paybox').'" onclick="window.location.href=\''.admin_url('admin.php').'?page=paybox\';" />' : '').'
				</form>
				<div class="paybox_buttons"><a class="paybox-button paybox-button-small" href="'.admin_url('admin.php').'?page=paybox-add"><i class="paybox-fa paybox-fa-plus"></i><label>'.__('Upload New File', 'paybox').'</label></a></div>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
				<table class="paybox_records">
				<tr>
					<th>'.__('File', 'paybox').'</th>
					<th style="width: 240px;">'.__('Shortcode', 'paybox').'</th>
					<th style="width: 130px;">'.__('Min Price', 'paybox').'</th>
					<th style="width: 100px;">'.__('Downloads', 'paybox').'</th>
					<th style="width: 150px;"></th>
				</tr>';
		if (sizeof($rows) > 0) {
			foreach ($rows as $row) {
				$sql = "SELECT COUNT(id) AS sales FROM ".$wpdb->prefix."dd_transactions WHERE file_id = '".$row["id"]."' AND (payment_status = 'Completed' OR payment_status = 'Success' OR payment_status = 'confirmed' OR payment_status = 'complete') AND deleted = '0'";
				$sales = $wpdb->get_row($sql, ARRAY_A);
				echo '
				<tr>
					<td><strong>'.$row['title'].'</strong><br /><em style="font-size: 12px; line-height: 14px;">'.esc_html($row['filename_original']).'</em></td>
					<td><input type="text" class="widefat" onclick="this.focus();this.select();" readonly="readonly" value="'.(defined('UAP_CORE') ? esc_html('<div class="paybox" data-id="'.$row['id'].'"></div>') : esc_html('[paybox id="'.$row['id'].'"]')).'"></td>
					<td style="text-align: right;">'.($row['currency'] == 'BTC' ? number_format($row['price'], 8) : number_format($row['price'], 2)).' '.$row['currency'].'</td>
					<td style="text-align: right;">'.intval($sales["sales"]).' / '.(($row['available_copies'] == 0) ? '&infin;' : $row['available_copies']).'</td>
					<td class="paybox-item-actions">
						<a href="'.admin_url('admin.php').'?page=paybox-add&id='.$row['id'].'" title="'.__('Edit file details', 'paybox').'"><i class="paybox-fa paybox-fa-pencil"></i></a>
						<a href="'.admin_url('admin.php').'?page=paybox-add-link&fid='.$row['id'].'" title="'.__('Generate download link', 'paybox').'"><i class="paybox-fa paybox-fa-link"></i></a>
						<a href="'.admin_url('admin.php').'?page=paybox-links&fid='.$row['id'].'" title="'.__('Download links', 'paybox').'"><i class="paybox-fa paybox-fa-list-alt"></i></a>
						<a href="'.admin_url('admin.php').'?page=paybox-transactions&fid='.$row['id'].'" title="'.__('Payment transactions', 'paybox').'"><i class="paybox-fa paybox-fa-money"></i></a>
						<a href="'.(defined('UAP_CORE') ? esc_html(admin_url('admin.php').'?paybox-id='.$row['id']) : esc_html(get_bloginfo("url").'?paybox-id='.$row['id'])).'" title="'.__('Download file', 'paybox').'"><i class="paybox-fa paybox-fa-download"></i></a>
						<a href="'.admin_url('admin.php').'?action=paybox_delete&id='.$row['id'].'" title="'.__('Delete file', 'paybox').'" onclick="return paybox_confirm_redirect(this, \'delete\');"><i class="paybox-fa paybox-fa-trash"></i></a>
					</td>
				</tr>';
			}
		} else {
			echo '
				<tr><td colspan="5" style="padding: 20px; text-align: center;">'.((strlen($search_query) > 0) ? __('No results found for', 'paybox').' "<strong>'.esc_html($search_query).'</strong>"' : __('List is empty.', 'paybox')).'</td></tr>';
		}
		echo '
				</table>
				<div class="paybox_buttons"><a class="paybox-button paybox-button-small" href="'.admin_url('admin.php').'?page=paybox-add"><i class="paybox-fa paybox-fa-plus"></i><label>'.__('Upload New File', 'paybox').'</label></a></div>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
			</div>';
		echo $this->admin_modal_html();
	}

	function admin_add_file() {
		global $wpdb;

		unset($id);
		$status = "";
		if (isset($_GET["id"]) && !empty($_GET["id"])) {
			$id = intval($_GET["id"]);
			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
			if (intval($file_details["id"]) == 0) unset($id);
		}
		$errors = true;
		if (!empty($this->error)) $message = "<div class='error'><p>".$this->error."</p></div>";
		else if (!empty($this->info)) $message = "<div class='updated'><p>".$this->info."</p></div>";
		else $message = '';

		$files = array();
		$upload_dir = wp_upload_dir();
		if (file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files') && is_dir($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files')) {
			$dircontent = scandir($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files');
			for ($i=0; $i<sizeof($dircontent); $i++) {
				if ($dircontent[$i] != "." && $dircontent[$i] != ".." && $dircontent[$i] != "index.html" && $dircontent[$i] != ".htaccess") {
					if (is_file($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$dircontent[$i])) {
						$files[] = $dircontent[$i];
					}
				}
			}
		}
		if (!isset($file_details)) {
			$file_details = $this->default_file_details;
		}
		echo '
		<div class="wrap paybox">
			<h2>'.(!empty($id) ? __('Digital Paybox - Edit File', 'paybox') : __('Digital Paybox - Upload New File', 'paybox')).'</h2>
			'.$message.'
			<form enctype="multipart/form-data" method="post" style="margin: 0px" action="'.admin_url('admin.php').'">
			<div class="postbox-container" style="width: 100%;">
				<div class="metabox-holder">
					<div class="meta-box-sortables ui-sortable">
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.(!empty($id) ? __('Edit file', 'paybox') : __('Upload new file', 'paybox')).'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('Title', 'paybox').':</th>
										<td><input type="text" name="paybox_title" id="paybox_title" value="'.esc_html($file_details['title']).'" class="widefat"><br /><em>'.__('Enter the title of file. If you leave this field blank, then original file name will be the title.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('File', 'paybox').':</th>
										<td>
											<select name="paybox_fileselector" id="paybox_fileselector">
												<option value="">-- '.__('Select available file', 'paybox').' --</option>';
		for ($i=0; $i<sizeof($files); $i++) {
			echo '
												<option value="'.esc_html($files[$i]).'"'.($files[$i] == $file_details['filename'] ? ' selected="selected"' : '').'>'.esc_html($files[$i]).'</option>';
		}
		echo '
											</select><br /><em>'.__('Select any available file from folder <strong>/wp-content/uploads/paybox/files/</strong> or upload new file below.', 'paybox').'</em><br /><br />
											<input type="file" name="paybox_file" id="paybox_file" class="widefat"><br /><em>'.__('Choose file to upload.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Description:', 'paybox').'</th>
										<td>
											<textarea class="widefat" id="paybox_intro" name="paybox_intro" style="height: 120px;">'.esc_html($file_details['intro']).'</textarea>
											<br /><em>'.__('Please enter file description. HTML allowed. Payment form is inserted below this content. Allowed keywords: {min_amount}, {currency}.', 'paybox').'</em>
										</td>
									</tr> 
									<tr>
										<th>'.__('Min Price', 'paybox').':</th>
										<td>
											<input type="text" name="paybox_price" id="paybox_price" value="'.(!empty($id) ? ($file_details['currency'] == 'BTC' ? number_format($file_details['price'], 8, '.', '') : number_format($file_details['price'], 2, '.', '')) : '0.00').'" style="width: 100px; text-align: right;">
											<select name="paybox_currency" id="paybox_currency" onchange="paybox_supportedmethods();">';
		foreach ($this->currency_list as $currency) {
			echo '
												<option value="'.$currency.'"'.($currency == $file_details['currency'] ? ' selected="selected"' : '').'>'.$currency.'</option>';
		}
		echo '								
											</select>
											<label id="paybox_supported"></label>
											<br /><em>'.__('Set the minimum payment value for the file to be downloaded or leave this field blank (or set 0) for free downloading.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Fixed price', 'paybox').':</th>
										<td><input type="checkbox" id="paybox_fixed_price" name="paybox_fixed_price" '.($file_details['fixed_price'] == 1 ? 'checked="checked"' : '').'"> '.__('Set fixed price', 'paybox').'<br /><em>'.__('Please tick checkbox if you would like to set fixed price for this file. Users can not set desired payment amount if this option enabled.', 'paybox').'</em></td>
									</tr>
									<tr>
										<th>'.__('Available copies', 'paybox').':</th>
										<td><input type="text" name="paybox_available_copies" id="paybox_available_copies" value="'.(!empty($id) ? intval($file_details['available_copies']) : '0').'" style="width: 80px; text-align: right;"><br /><em>'.__('Set how many copies of the file you would like to sell. After distributing this number of copies, payment form for the file will not be displayed. Leave this field blank (or set 0) if you wish to distribute unlimited number of copies. This field is ignored if you distribute the file freely.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
				<hr>
				<div class="paybox-button-container">
					<input type="hidden" name="action" value="paybox_update_file" />
					'.(!empty($id) ? '<input type="hidden" name="paybox_id" value="'.$id.'" />' : '').'
					<a class="paybox-button" onclick="jQuery(this).closest(\'form\').submit(); return false;"><i class="paybox-fa paybox-fa-ok"></i><label>Submit Details</label></a>
				</div>
			</div>
			</form>
			<script type="text/javascript">
				function paybox_supportedmethods() {
					var paypal_currencies = new Array("'.implode('", "', $this->paypal_currency_list).'");
					var perfect_currencies = new Array("'.implode('", "', $this->perfect_currency_list).'");
					var payza_currencies = new Array("'.implode('", "', $this->payza_currency_list).'");
					var skrill_currencies = new Array("'.implode('", "', $this->skrill_currency_list).'");
					var bitpay_currencies = new Array("'.implode('", "', $this->bitpay_currency_list).'");
					var stripe_currencies = new Array("'.implode('", "', $this->stripe_currency_list).'");
					var blockchain_currencies = new Array("'.implode('", "', $this->blockchain_currency_list).'");
					var interkassa_currencies = new Array("'.implode('", "', $this->interkassa_currency_list).'");
					var currency = jQuery("#paybox_currency").val();
					var supported = "";
					if (currency == "USD") supported = supported + "<span>Authorize.Net</span>";
					if (jQuery.inArray(currency, bitpay_currencies) >= 0) supported = supported + "<span>BitPay</span>";
					if (jQuery.inArray(currency, blockchain_currencies) >= 0) supported = supported + "<span>Blockchain.info</span>";
					if (jQuery.inArray(currency, interkassa_currencies) >= 0) supported = supported +"<span>InterKassa</span>";
					if (jQuery.inArray(currency, paypal_currencies) >= 0) supported = supported + "<span>PayPal</span>";
					if (jQuery.inArray(currency, payza_currencies) >= 0) supported = supported + "<span>Payza</span>";
					if (jQuery.inArray(currency, perfect_currencies) >= 0) supported = supported + "<span>PerfectMoney</span>";
					if (jQuery.inArray(currency, skrill_currencies) >= 0) supported = supported + "<span>Skrill</span>";
					if (jQuery.inArray(currency, stripe_currencies) >= 0) supported = supported + "<span>Stripe</span>";
					jQuery("#paybox_supported").html("'.__('Supported payment methods:', 'paybox').' " + supported);
				}
				paybox_supportedmethods();
			</script>			
		</div>';
	}

	function admin_links() {
		global $wpdb;

		if (isset($_GET["fid"])) $file_id = intval(trim(stripslashes($_GET["fid"])));
		else $file_id = 0;
		
		$tmp = $wpdb->get_row("SELECT COUNT(*) AS total FROM ".$wpdb->prefix."dd_downloadlinks WHERE deleted = '0'".($file_id > 0 ? " AND file_id = '".$file_id."'" : ""), ARRAY_A);
		$total = $tmp["total"];
		$totalpages = ceil($total/PAYBOX_RECORDS_PER_PAGE);
		if ($totalpages == 0) $totalpages = 1;
		if (isset($_GET["p"])) $page = intval($_GET["p"]);
		else $page = 1;
		if ($page < 1 || $page > $totalpages) $page = 1;
		$switcher = $this->page_switcher(admin_url('admin.php').'?page=paybox-links'.($file_id > 0 ? '&fid='.$file_id : ''), $page, $totalpages);

		$sql = "SELECT t1.*, t2.title AS file_title FROM ".$wpdb->prefix."dd_downloadlinks t1 LEFT JOIN ".$wpdb->prefix."dd_files t2 ON t2.id = t1.file_id WHERE t1.deleted = '0'".($file_id > 0 ? " AND file_id = '".$file_id."'" : "")." ORDER BY t1.created DESC LIMIT ".(($page-1)*PAYBOX_RECORDS_PER_PAGE).", ".PAYBOX_RECORDS_PER_PAGE;
		$rows = $wpdb->get_results($sql, ARRAY_A);
		if (!empty($this->error)) $message = "<div class='error'><p>".$this->error."</p></div>";
		else if (!empty($this->info)) $message = "<div class='updated'><p>".$this->info."</p></div>";
		else $message = '';

		echo '
			<div class="wrap admin_paybox_wrap">
				<h2>'.__('Digital Paybox - Download Links', 'paybox').'</h2>
				'.$message.'
				<div class="paybox_buttons"><a class="paybox-button paybox-button-small" href="'.admin_url('admin.php').'?page=paybox-add-link'.($file_id > 0 ? '&fid='.$file_id : '').'"><i class="paybox-fa paybox-fa-plus"></i><label>'.__('Add New Link', 'paybox').'</label></a></div>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
				<table class="paybox_records">
				<tr>
					<th>'.__('Download Link', 'paybox').'</th>
					<th style="width: 180px;">'.__('Owner', 'paybox').'</th>
					<th style="width: 160px;">'.__('File', 'paybox').'</th>
					<th style="width: 80px;">'.__('Source', 'paybox').'</th>
					<th style="width: 30px;"></th>
				</tr>';
		if (sizeof($rows) > 0) {
			foreach ($rows as $row) {
				if (time() <= $row["created"] + 24*3600*$this->options['link_lifetime']) {
					$expired = "Expires in ".$this->period_to_string($row["created"] + 24*3600*$this->options['link_lifetime'] - time()).'.';
				} else {
					$expired = "Link expired.";
				}
				echo '
				<tr>
					<td><input type="text" class="widefat" onclick="this.focus();this.select();" readonly="readonly" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-key='.$row["download_key"]) : esc_html(get_bloginfo('url').'/?paybox-key='.$row["download_key"])).'">'.(!empty($expired) ? '<br /><em>'.$expired.'</em>' : '').'</td>
					<td>'.esc_html($row['owner']).'</td>
					<td>'.(!empty($row['file_title']) ? esc_html($row['file_title']) : '-').'</td>
					<td>'.esc_html($row['source']).'</td>
					<td class="paybox-item-actions">
						<a href="'.admin_url('admin.php').'?action=paybox_delete_link&id='.$row['id'].'" title="'.__('Delete download link', 'paybox').'" onclick="return paybox_confirm_redirect(this, \'delete\');"><i class="paybox-fa paybox-fa-trash"></i></a>
					</td>
				</tr>
				';
			}
		} else {
			echo '
				<tr><td colspan="5" style="padding: 20px; text-align: center;">'.__('List is empty.', 'paybox').'</td></tr>';
		}
		echo '
				</table>
				<div class="paybox_buttons"><a class="paybox-button paybox-button-small" href="'.admin_url('admin.php').'?page=paybox-add-link'.($file_id > 0 ? '&fid='.$file_id : '').'"><i class="paybox-fa paybox-fa-plus"></i><label>'.__('Add New Link', 'paybox').'</label></a></div>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
			</div>';
		echo $this->admin_modal_html();
	}

	function admin_add_link() {
		global $wpdb;

		if (isset($_GET["fid"])) $file_id = intval(trim(stripslashes($_GET["fid"])));
		else $file_id = 0;
		
		if (!empty($this->error)) $message = "<div class='error'><p>".$this->error."</p></div>";
		else if (!empty($this->info)) $message = "<div class='updated'><p>".$this->info."</p></div>";
		else $message = '';

		$sql = "SELECT * FROM ".$wpdb->prefix."dd_files WHERE deleted = '0' ORDER BY registered DESC";
		$files = $wpdb->get_results($sql, ARRAY_A);
		if (empty($files)) {
			echo '
			<div class="wrap admin_paybox_wrap">
				<div id="icon-options-general" class="icon32"><br /></div><h2>'.__('Digital Paybox - Add Download Link', 'paybox').'</h2>
				<div class="error"><p>'.__('Please uplad at least one file first.', 'paybox').'</p></div>
			</div>';
			return;
		}

		echo '
		<div class="wrap paybox">
			<h2>'.__('Digital Paybox - Add Download Link', 'paybox').'</h2>
			'.$message.'
			<form class="paybox-form" enctype="multipart/form-data" method="post" style="margin: 0px" action="'.admin_url('admin.php').'">
			<div class="postbox-container" style="width: 100%;">
				<div class="metabox-holder">
					<div class="meta-box-sortables ui-sortable">
						<div class="postbox paybox_postbox">
							<!--<div class="handlediv" title="Click to toggle"><br></div>-->
							<h3 class="hndle" style="cursor: default;"><span>'.__('Add download link', 'paybox').'</span></h3>
							<div class="inside">
								<table class="paybox_useroptions">
									<tr>
										<th>'.__('File', 'paybox').':</th>
										<td>
											<select name="paybox_fileselector" id="paybox_fileselector">
												<option value="">-- '.__('Select file', 'paybox').' --</option>';
		foreach ($files as $file) {
			echo '
												<option value="'.$file["id"].'"'.($file["id"] == $file_id ? 'selected="selected"' : '').'>'.esc_html($file["title"]).'</option>';
		}
		echo '
											</select><br /><em>'.__('Select any uploaded file.', 'paybox').'</em>
										</td>
									</tr>
									<tr>
										<th>'.__('Link owner', 'paybox').':</th>
										<td><input type="text" name="paybox_link_owner" id="paybox_link_owner" value="" style="width: 50%;"><br /><em>'.__('Please enter e-mail for which you are generating the link. You must send generated link manually.', 'paybox').'</em></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
				<hr>
				<div class="paybox-button-container">
					<input type="hidden" name="action" value="paybox-create-link" />
					<a class="paybox-button" onclick="return paybox_create_link(this);"><i class="paybox-fa paybox-fa-ok"></i><label>'.esc_html__('Generate Link', 'paybox').'</label></a>
				</div>
				<div class="paybox-message"></div>
			</div>
			</form>
			<div id="paybox-global-message"></div>
		</div>';
	}

	function admin_create_link() {
		global $wpdb;
		if (current_user_can('manage_options')) {
			$errors = array();
			$link_owner = trim(stripslashes($_REQUEST["paybox_link_owner"]));
			if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $link_owner) || empty($link_owner)) $errors[] = __('Link owner must be valid e-mail address.', 'paybox');
			$file_id = trim(stripslashes($_REQUEST["paybox_fileselector"]));
			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$file_id."' AND deleted = '0'", ARRAY_A);
			if (empty($file_details)) $errors[] = __('File not found.', 'paybox');
			
			if (!empty($errors)) {
				$return_object = array();
				$return_object['status'] = 'ERROR';
				$return_object['message'] = __('Attention! Please correct errors and try again.', 'paybox').'<ul><li>'.implode('</li><li>', $errors).'</li></ul>';
				echo json_encode($return_object);
				exit;
			}
			
			$link = $this->generate_downloadlink($file_details["id"], $link_owner, "manual");
			$return_object = array();
			$return_object['status'] = 'OK';
			$return_object['message'] = __('Download link successfully created.', 'paybox');
			$return_object['redirect_url'] = admin_url('admin.php').'?page=paybox-links';
			echo json_encode($return_object);
			exit;
		}
	}
	
	function admin_transactions() {
		global $wpdb;

		if (!empty($this->error)) $message = "<div class='error'><p>".$this->error."</p></div>";
		else if (!empty($this->info)) $message = "<div class='updated'><p>".$this->info."</p></div>";
		else $message = '';

		if (isset($_GET["s"])) $search_query = trim(stripslashes($_GET["s"]));
		else $search_query = "";
		if (isset($_GET["fid"])) $file_id = intval(trim(stripslashes($_GET["fid"])));
		else $file_id = 0;
		$tmp = $wpdb->get_row("SELECT COUNT(*) AS total FROM ".$wpdb->prefix."dd_transactions WHERE deleted = '0'".($file_id > 0 ? " AND file_id = '".$file_id."'" : "").((strlen($search_query) > 0) ? " AND (payer_name LIKE '%".addslashes($search_query)."%' OR payer_email LIKE '%".addslashes($search_query)."%')" : ""), ARRAY_A);
		$total = $tmp["total"];
		$totalpages = ceil($total/PAYBOX_RECORDS_PER_PAGE);
		if ($totalpages == 0) $totalpages = 1;
		if (isset($_GET["p"])) $page = intval($_GET["p"]);
		else $page = 1;
		if ($page < 1 || $page > $totalpages) $page = 1;
		$switcher = $this->page_switcher(admin_url('admin.php').'?page=paybox-transactions'.((strlen($search_query) > 0) ? "&s=".rawurlencode($search_query) : "").($file_id > 0 ? "&fid=".$file_id : ""), $page, $totalpages);

		$sql = "SELECT t1.*, t2.title AS file_title FROM ".$wpdb->prefix."dd_transactions t1 LEFT JOIN ".$wpdb->prefix."dd_files t2 ON t1.file_id = t2.id WHERE t1.deleted = '0'".($file_id > 0 ? " AND t1.file_id = '".$file_id."'" : "").((strlen($search_query) > 0) ? " AND (t1.payer_name LIKE '%".addslashes($search_query)."%' OR t1.payer_email LIKE '%".addslashes($search_query)."%')" : "")." ORDER BY t1.created DESC LIMIT ".(($page-1)*PAYBOX_RECORDS_PER_PAGE).", ".PAYBOX_RECORDS_PER_PAGE;
		$rows = $wpdb->get_results($sql, ARRAY_A);

		echo '
			<div class="wrap admin_paybox_wrap">
				<h2>'.__('Digital Paybox - Transactions', 'paybox').'</h2>
				'.$message.'
				<form action="'.admin_url('admin.php').'" method="get" class="uap-filter-form paybox-filter-form">
				<input type="hidden" name="page" value="paybox-transactions" />
				'.($file_id > 0 ? '<input type="hidden" name="bid" value="'.$file_id.'" />' : '').'
				<label>'.__('Search:', 'paybox').'</label>
				<input type="text" name="s" value="'.esc_html($search_query).'" style="width: 200px;" class="form-control">
				<input type="submit" class="button-secondary action" value="'.__('Search', 'paybox').'" />
				'.((strlen($search_query) > 0) ? '<input type="button" class="button-secondary action" value="'.__('Reset search results', 'paybox').'" onclick="window.location.href=\''.admin_url('admin.php').'?page=paybox-transactions'.($file_id > 0 ? '&bid='.$file_id : '').'\';" />' : '').'
				</form>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
				<table class="paybox_records">
				<tr>
					<th>'.__('File', 'paybox').'</th>
					<th>'.__('Payer', 'paybox').'</th>
					<th style="width: 130px;">'.__('Amount', 'paybox').'</th>
					<th style="width: 120px;">'.__('Status', 'paybox').'</th>
					<th style="width: 130px;">'.__('Created', 'paybox').'</th>
					<th style="width: 30px;"></th>
				</tr>';
		if (sizeof($rows) > 0) {
			foreach ($rows as $row) {
				echo '
				<tr>
					<td>'.esc_html($row['file_title']).'</td>
					<td>'.esc_html($row['payer_name']).'<br /><em>'.esc_html($row['payer_email']).'</em></td>
					<td style="text-align: right;">'.($row['currency'] == 'BTC' ? number_format($row['gross'], 8, ".", "") : number_format($row['gross'], 2, ".", "")).' '.$row['currency'].'</td>
					<td>
						<a onclick="return paybox_admin_popup_open(this);" data-id="'.esc_html($row['id']).'" data-title="'.esc_html__('Transaction Details', 'paybox').'" data-subtitle="'.esc_html($row['payer_email']).'" data-action="paybox-transaction-details" href="#" title="'.esc_html__('View transaction details', 'paybox').': '.esc_html($row['payer_email']).'">'.esc_html($row["payment_status"]).'</a><br /><em>'.esc_html($row["transaction_type"]).'</em>						
					</td>
					<td>'.date("Y-m-d H:i", $row["created"]).'</td>
					<td class="paybox-item-actions">
						<a href="'.admin_url('admin.php').'?action=paybox_delete_txn&id='.$row['id'].'" title="'.__('Delete transaction', 'paybox').'" onclick="return paybox_confirm_redirect(this, \'delete\');"><i class="paybox-fa paybox-fa-trash"></i></a>
					</td>
					
				</tr>';
			}
		} else {
			echo '
				<tr><td colspan="6" style="padding: 20px; text-align: center;">'.((strlen($search_query) > 0) ? __('No results found for', 'paybox').' "<strong>'.esc_html($search_query).'</strong>"' : __('List is empty.', 'paybox')).'</td></tr>';
		}
		echo '
				</table>
				<div class="paybox_pageswitcher">'.$switcher.'</div>
			</div>
			<div class="paybox-admin-popup-overlay" id="paybox-admin-popup-overlay"></div>
			<div class="paybox-admin-popup" id="paybox-admin-popup">
				<div class="paybox-admin-popup-inner">
					<div class="paybox-admin-popup-title">
						<a href="#" title="'.esc_html__('Close', 'paybox').'" onclick="return paybox_admin_popup_close();"><i class="paybox-fa paybox-fa-cancel"></i></a>
						<h3><label></label><span></span></h3>
					</div>
					<div class="paybox-admin-popup-content">
						<div class="paybox-admin-popup-content-form">
						</div>
					</div>
					<div class="paybox-admin-popup-loading"><i class="paybox-fa paybox-fa-spinner paybox-fa-spin"></i></div>
				</div>
			</div>
			<div id="paybox-global-message"></div>';
		echo $this->admin_modal_html();
	}

	function admin_transaction_details() {
		global $wpdb;
		if (current_user_can('manage_options')) {
			$callback = '';
			$html = '';
			if (isset($_REQUEST['callback'])) {
				header("Content-type: text/javascript");
				$callback = preg_replace('/[^a-zA-Z0-9_]/', '', $_REQUEST['callback']);
			}
			$id = null;
			if (array_key_exists('id', $_REQUEST)) {
				$id = intval($_REQUEST['id']);
				$transaction_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_transactions WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
				if (empty($transaction_details)) $id = null;
			}
			if (empty($id)) {
				$return_data = array(
					'status' => 'ERROR',
					'message' => esc_html__('Requested record not found.', 'paybox')
				);
				if (!empty($callback)) echo $callback.'('.json_encode($return_data).')';
				else echo json_encode($return_data);
				exit;
			}
			$details = json_decode($transaction_details["details"], true);
			if (empty($details)) {
				$html .= '
	<table class="paybox-admin-popup-table">';
				$details = explode("&", $transaction_details["details"]);
				foreach ($details as $param) {
					$data = explode("=", $param, 2);
					$html .= '
		<tr>
			<th>'.esc_html($data[0]).'</th>
			<td>'.esc_html(urldecode($data[1])).'</td>
		</tr>';
				}
				$html .= '
	</table>';
			} else {
				$html .= '
	<table class="paybox-admin-popup-table">';
				$html .= $this->_transaction_details(0, $details);
				$html .= '
	</table>';
			}
			$return_data = array(
				'status' => 'OK',
				'html' => $html
			);
			if (!empty($callback)) echo $callback.'('.json_encode($return_data).')';
			else echo json_encode($return_data);
		}
		exit;
	}

	function _transaction_details($_level, $_details) {
		$html = '';
		$prefix = '';
		for ($i=0; $i<$_level; $i++) {
			$prefix .= '&nbsp;&nbsp;';
		}
		foreach ($_details as $key => $value) {
			if (is_array($value)) {
				$html .= '<tr><th colspan="2">'.$prefix.esc_html($key).'</th></tr>';
				$html .= $this->_transaction_details($_level+1, $value);
			} else {
				$html .= '
		<tr>
			<th>'.$prefix.esc_html($key).'</th>
			<td>'.esc_html($value).'</td>
		</tr>';
			}
		}
		return $html;
	}

	function admin_using() {
		global $wpdb;
		$remote_snippet = '<script id="paybox-remote" src="'.plugins_url('/js/remote.js', __FILE__).'?ver='.PAYBOX_VERSION.'" data-handler="'.admin_url('admin-ajax.php').'"></script>';
		echo '
		<div class="wrap paybox">
			<h2>Digital Paybox - How To Use</h2>
			<div class="paybox_postbox paybox-using-page">
				<h3>Embedding Digital Paybox into website</h3>
				<p>To embed Digital Paybox into any website you need perform the following steps:</p>
				<ol>
				<li>
					Make sure that website has DOCTYPE. If not, add the following line as a first line of HTML-document:
					<input type="text" readonly="readonly" value="&lt;!DOCTYPE html&gt;" onclick="this.focus();this.select();">
				</li>
				<li>
					Make sure that website loads jQuery version 1.9 or higher. If not, add the following line into head section of HTML-document:
					<input type="text" readonly="readonly" value="&lt;script src=&quot;https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js&quot;&gt;&lt;/script&gt;" onclick="this.focus();this.select();">
				</li>
				<li>
					Copy the following JS-snippet and paste it into your website. You need paste it at the end of <code>&lt;body&gt;</code> section (above closing <code>&lt;/body&gt;</code> tag).
					<input type="text" readonly="readonly" onclick="this.focus();this.select();" value="'.esc_html($remote_snippet).'" />
				</li>
				<li>That\'s it. Integration finished. :-)</li>
				</ol>
				<h3>Using Digital Paybox</h3>
				<p>Copy file\'s shortcode and paste it where payment form must be. Shortcodes can be found on <a href="'.admin_url('admin.php').'?page=paybox">Files</a> page.</p>
			</div>
		</div>';
	}
	
	function admin_request_handler() {
		global $wpdb;
		if (!empty($_POST['action'])) {
			switch($_POST['action']) {
				case 'paybox_update_file':
					$file_details = array();
					if (isset($_POST["paybox_id"]) && !empty($_POST["paybox_id"])) {
						$id = intval($_POST["paybox_id"]);
						$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
						if (empty($file_details)) unset($id);
					}
					$title = trim(stripslashes($_POST["paybox_title"]));
					$intro = trim(stripslashes($_POST["paybox_intro"]));
					if (isset($_POST["paybox_fixed_price"])) $fixed_price = 1;
					else $fixed_price = 0;
					$currency = trim(stripslashes($_POST["paybox_currency"]));
					$price = trim(stripslashes($_POST["paybox_price"]));
					$price = ($currency == 'BTC' ? number_format(floatval($price), 8, '.', '') : number_format(floatval($price), 2, '.', ''));
					$available_copies = trim(stripslashes($_POST["paybox_available_copies"]));
					$available_copies = intval($available_copies);
					$file_selector = trim(stripslashes($_POST["paybox_fileselector"]));
					$upload_dir = wp_upload_dir();
					if (is_uploaded_file($_FILES["paybox_file"]["tmp_name"])) {
						$uploaded = 1;
						if (empty($title)) $title = $_FILES["paybox_file"]["name"];
						if (isset($file_details["uploaded"]) && $file_details["uploaded"] == 1) {
							if (file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"]) && is_file($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"]))
								unlink($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"]);
						}
						$filename = $this->get_filename($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR, $_FILES["paybox_file"]["name"]);
						$filename_original = $_FILES["paybox_file"]["name"];
						if (!move_uploaded_file($_FILES["paybox_file"]["tmp_name"], $upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$filename)) {
							setcookie("paybox_error", __('Unable to save uploaded file on server', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox-add'.(!empty($id) ? '&id='.$id : ''));
							exit;
						}
					} else {
						if (file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_selector) && is_file($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_selector)) {
							$filename = $file_selector;
							$filename_original = $filename;
							if (empty($title)) $title = $filename;
							if (isset($file_details["filename"]) && $file_selector == $file_details["filename"]) {
								$uploaded = 1;
								$filename_original = $file_details["filename_original"];
							} else {
								$uploaded = 0;
								$filename_original = $filename;
							}
						} else {
							setcookie("paybox_error", __('You must select or upload file', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox-add'.(!empty($id) ? '&id='.$id : ''));
							exit;
						}
					}
					if (!empty($id)) {
						$sql = "UPDATE ".$wpdb->prefix."dd_files SET 
							title = '".esc_sql($title)."', 
							intro = '".esc_sql($intro)."', 
							filename = '".esc_sql($filename)."', 
							filename_original = '".esc_sql($filename_original)."', 
							price = '".$price."',
							currency = '".$currency."',
							fixed_price = '".$fixed_price."',
							available_copies = '".$available_copies."',
							uploaded = '".$uploaded."'
							WHERE id = '".$id."'";
						if ($wpdb->query($sql) !== false) {
							setcookie("paybox_info", __('File successfully updated', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox');
							exit;
						} else {
							setcookie("paybox_error", __('Service is not available', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox-add'.(!empty($id) ? '&id='.$id : ''));
							exit;
						}
					} else {
						$sql = "INSERT INTO ".$wpdb->prefix."dd_files (
							title, intro, filename, filename_original, price, currency, fixed_price, registered, available_copies, uploaded, deleted) VALUES (
							'".esc_sql($title)."',
							'".esc_sql($intro)."',
							'".esc_sql($filename)."',
							'".esc_sql($filename_original)."',
							'".$price."',
							'".$currency."',
							'".$fixed_price."',
							'".time()."',
							'".$available_copies."',
							'".$uploaded."',
							'0'
							)";
						if ($wpdb->query($sql) !== false) {
							setcookie("paybox_info", __('File successfully added', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox');
							exit;
						} else {
							setcookie("paybox_error", __('Service is not available', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
							header('Location: '.admin_url('admin.php').'?page=paybox-add'.(!empty($id) ? '&id='.$id : ''));
							exit;
						}
					}
					break;
				default:
					break;
			}
		}
		if (!empty($_GET['action'])) {
			switch($_GET['action']) {
				case 'paybox_delete':
					$id = intval($_GET["id"]);
					$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
					if (intval($file_details["id"]) == 0) {
						setcookie("paybox_error", __('Invalid service call', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox');
						die();
					}
					$upload_dir = wp_upload_dir();
					$sql = "UPDATE ".$wpdb->prefix."dd_files SET deleted = '1' WHERE id = '".$id."'";
					if ($wpdb->query($sql) !== false) {
						if (file_exists($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"]) && is_file($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"])) {
							$tmp_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE filename = '".$file_details["filename"]."' AND deleted = '0'", ARRAY_A);
							if (intval($tmp_details["id"]) == 0 && $file_details["uploaded"] == 1) {
								unlink($upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"]);
							}
						}
						setcookie("paybox_info", __('File successfully removed', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox');
						die();
					} else {
						setcookie("paybox_error", __('Invalid service call', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox');
						die();
					}
					break;
				case 'paybox_delete_link':
					$id = intval($_GET["id"]);
					$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_downloadlinks WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
					if (intval($file_details["id"]) == 0) {
						setcookie("paybox_error", __('Invalid service call', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-links');
						die();
					}
					$sql = "UPDATE ".$wpdb->prefix."dd_downloadlinks SET deleted = '1' WHERE id = '".$id."'";
					if ($wpdb->query($sql) !== false) {
						setcookie("paybox_info", __('Download link successfully removed.', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-links');
						die();
					} else {
						setcookie("paybox_error", __('Invalid service call.', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-links');
						die();
					}
					break;
				case 'paybox_delete_txn':
					$id = intval($_GET["id"]);
					$txn_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_transactions WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
					if (intval($txn_details["id"]) == 0) {
						setcookie("paybox_error", __('Invalid service call', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-transactions');
						die();
					}
					$sql = "UPDATE ".$wpdb->prefix."dd_transactions SET deleted = '1' WHERE id = '".$id."'";
					if ($wpdb->query($sql) !== false) {
						setcookie("paybox_info", __('Transaction successfully removed.', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-transactions');
						die();
					} else {
						setcookie("paybox_error", __('Invalid service call.', 'paybox'), time()+30, "/", ".".str_replace("www.", "", $_SERVER["SERVER_NAME"]));
						header('Location: '.admin_url('admin.php').'?page=paybox-transactions');
						die();
					}
					break;
				default:
					break;
					
			}
		}
	}

	function admin_warning() {
		echo '
		<div class="error paybox-error"><p><strong>Digital Paybox</strong> plugin is almost ready. You must do some <a href="'.admin_url('admin.php').'?page=paybox-settings">settings</a> to make it work properly.</p></div>';
	}

	function admin_warning_reactivate() {
		echo '
		<div class="error paybox-error"><p><strong>IMPORTANT!</strong> Please deactivate and activate <strong>Digital Paybox</strong> plugin <a href="'.admin_url('plugins.php').'">here</a>! It is necessary to sync database for additional functionality.</p></div>';
	}
	
	function front_init() {
		global $wpdb;
		if ((array_key_exists('REQUEST_URI', $_SERVER) && strpos($_SERVER['REQUEST_URI'], 'paybox-authnet-ipn-handler') !== false) || defined('UAP_CORE')) {
			$headers = getallheaders();
			if (is_array($headers) && array_key_exists('X-ANET-Signature', $headers)) {
				$payload = @file_get_contents('php://input');
				$post_data = json_decode($payload, true);
				if (!empty($post_data) && is_array($post_data) && array_key_exists('payload', $post_data) && is_array($post_data['payload']) && array_key_exists('merchantReferenceId', $post_data['payload']) && array_key_exists('entityName', $post_data['payload']) && $post_data['payload']['entityName'] == 'transaction') {
					$refid_parts = explode('-', $post_data['payload']['merchantReferenceId']);
					if ($refid_parts[0] == $this->options['authnet_webhook_uid']) {
						$item_number = intval($refid_parts[1]);
						$payment_status = $post_data['eventType'];
						$transaction_type = 'Tx';
						$txn_id = $post_data['payload']['id'];
						$payer_id = '';
						$payer_name = 'Unknown Payer';
						$gross_total = $post_data['payload']['authAmount'];
						$mc_currency = "USD";
						$statuses = array(
							'net.authorize.payment.authcapture.created' => 'Completed',
							'net.authorize.payment.authorization.created' => 'Completed',
							'net.authorize.payment.capture.created' => 'Completed',
							'net.authorize.payment.priorAuthCapture.created' => 'PriorAuthCapture',
							'net.authorize.payment.refund.created' => 'Refund',
							'net.authorize.payment.void.created' => 'Void'
						);
						if (array_key_exists($payment_status, $statuses)) {
							$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".esc_sql($item_number)."'", ARRAY_A);
							if (empty($file_details)) $payment_status = "No File";
							else {
								$payment_status = $statuses[$payment_status];
								if ($payment_status == 'Completed') {
									if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Invalid Amount";
									else {
										$signature_parts = explode('=', $headers['X-ANET-Signature']);
										$hash = strtoupper(hash_hmac("sha512", $payload, trim($this->options['authnet_signature_key'])));
										if ($hash != strtoupper($signature_parts[1])) $payment_status = "Invalid Hash";
										else {
											$headers = array(
												'Content-Type: application/json;charset=UTF-8',
												'Accept: application/json'
											);
											$request = array(
												'getTransactionDetailsRequest' => array(
													'merchantAuthentication' => array(
														'name' => $this->options['authnet_login_id'],
														'transactionKey' => $this->options['authnet_transaction_key']
													),
													'transId' => $post_data['payload']['id']
												)
											);
											$result = null;
											try {
												$url = ($this->options['authnet_sandbox'] == "on") ? 'https://apitest.authorize.net/xml/v1/request.api' : 'https://api.authorize.net/xml/v1/request.api';
												$curl = curl_init($url);
												curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
												curl_setopt($curl, CURLOPT_POST, true);
												curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($request));
												curl_setopt($curl, CURLOPT_TIMEOUT, 20);
												curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
												curl_setopt($curl, CURLOPT_FORBID_REUSE, true);
												curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
												curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
												curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
												$response = curl_exec($curl);
												curl_close($curl);
												$result = json_decode(preg_replace('/^'.pack('H*','EFBBBF').'/', '', $response), true);
											} catch (Exception $e) {
												$result = null;
											}
											if (empty($result) || !array_key_exists('transaction', $result)) $payment_status = "Invalid Tx";
											else {
												$post_data = array_merge($post_data, $result);
												if (array_key_exists('customer', $result['transaction']) && array_key_exists('email', $result['transaction']['customer']) && !empty($result['transaction']['customer']['email'])) {
													$payer_id = $result['transaction']['customer']['email'];
													$payer_name = $result['transaction']['customer']['email'];
												}
												//if (array_key_exists('transactionType', $result['transaction']) && !empty($result['transaction']['transactionType'])) {
												//	$transaction_type = $result['transaction']['transactionType'];
												//}
											}
										}
									}
								}
							}
							$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
								file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
								'".esc_sql($item_number)."',
								'".esc_sql($payer_name)."',
								'".esc_sql($payer_id)."',
								'".floatval($gross_total)."',
								'".$mc_currency."',
								'".$payment_status."',
								'Autorize.Net: ".$transaction_type."',
								'".$txn_id."',
								'".esc_sql(json_encode($post_data))."',
								'".time()."'
							)";
							$wpdb->query($sql);
							if ($payment_status == "Completed") {
								$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
								$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
								$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

								$body = str_replace($tags, $vals, $this->options['success_email_body']);
								$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
								$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
								$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
								wp_mail($payer_id, $this->options['success_email_subject'], $body, $mail_headers);

								$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Authorize.Net on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
								$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
								$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
								$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
								wp_mail($this->options['seller_email'], __('Completed Authorize.Net payment received', 'paybox'), $body, $mail_headers);
							} else {
								$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
								$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

								$body = str_replace($tags, $vals, $this->options['failed_email_body']);
								$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
								$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
								$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
								wp_mail($payer_id, $this->options['failed_email_subject'], $body, $mail_headers);

								$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Authorize.Net on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
								$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
								$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
								$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
								wp_mail($this->options['seller_email'], __('Non-completed Authorize.Net payment received', 'paybox'), $body, $mail_headers);
							}
						}
						http_response_code(200);
						exit;
					}
				}
			}
		}
		if (isset($_GET['paybox-id']) || isset($_GET['paybox-key'])) {
			error_reporting(0);
			ob_start();
			if(!ini_get('safe_mode')) set_time_limit(0);
			ob_end_clean();
			if (isset($_GET["paybox-id"])) {
				$id = intval($_GET["paybox-id"]);
				$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "dd_files WHERE id = '".$id."' AND deleted = '0'", ARRAY_A);
				if (intval($file_details["id"]) == 0) die(__('Invalid download link', 'paybox'));
				if ($file_details["price"] != 0 && !current_user_can('manage_options')) die(__('Invalid download link', 'paybox'));
			} else {
				if (!isset($_GET["paybox-key"])) die(__('Invalid download link', 'paybox'));
				$download_key = $_GET["paybox-key"];
				$download_key = preg_replace('/[^a-zA-Z0-9]/', '', $download_key);
				$sql = "SELECT * FROM ".$wpdb->prefix."dd_downloadlinks WHERE download_key = '".$download_key."' AND deleted = '0'";
				$link_details = $wpdb->get_row($sql, ARRAY_A);
				if (intval($link_details["id"]) == 0) die(__('Invalid download link', 'paybox'));
				$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix . "dd_files WHERE id = '".$link_details["file_id"]."' AND deleted = '0'", ARRAY_A);
				if (intval($file_details["id"]) == 0) die(__('Invalid download link', 'paybox'));
				if ($link_details["created"]+24*3600*intval($this->options['link_lifetime']) < time()) die(__('Download link was expired', 'paybox'));
			}
			$upload_dir = wp_upload_dir();
			$filename = $upload_dir["basedir"].DIRECTORY_SEPARATOR.PAYBOX_UPLOADS_DIR.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.$file_details["filename"];
			$filename_original = $file_details["filename_original"];

			if (!file_exists($filename) || !is_file($filename)) die(__('File not found', 'paybox'));

			if ($this->options['xsendfile'] == 'on') {
				header('X-Sendfile: '.$filename);
				header('Content-type: application/octet-stream');
				header('Content-Disposition: attachment; filename="'.$filename_original.'"');
			} else {
				$length = filesize($filename);
				if (strstr($_SERVER["HTTP_USER_AGENT"],"MSIE")) {
					header("Pragma: public");
					header("Expires: 0");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Content-type: application-download");
					header("Content-Length: ".$length);
					header("Content-Disposition: attachment; filename=\"".$filename_original."\"");
					header("Content-Transfer-Encoding: binary");
				} else {
					header("Content-type: application-download");
					header("Content-Length: ".$length);
					header("Content-Disposition: attachment; filename=\"".$filename_original."\"");
				}
				ob_end_clean();
				$handle_read = fopen($filename, "rb");
				while (!feof($handle_read) && $length > 0) {
					$content = fread($handle_read, 1024);
					echo substr($content, 0, min($length, 1024));
					flush();
					ob_flush();
					$length = $length - strlen($content);
					if ($length < 0) $length = 0;
				}
				fclose($handle_read);
			}
			exit;
		} else if (isset($_REQUEST['paybox-ipn']) && $_REQUEST['paybox-ipn'] == 'payza') {
			$token = "token=".urlencode($_POST['token']);
			$response = '';
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, ($this->options['payza_sandbox'] == 'on' ? "https://sandbox.payza.com/sandbox/IPN2.ashx" : "https://secure.payza.com/ipn2.ashx"));
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $token);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_TIMEOUT, 60);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($ch);
			if(strlen($response) > 0) {
				if(urldecode($response) == "INVALID TOKEN") {
					//the token is not valid
				} else {
					$response = urldecode($response);
					$aps = explode("&", $response);
					$info = array();
					foreach ($aps as $ap) {
						$ele = explode("=", $ap);
						$info[$ele[0]] = $ele[1];
					}

					$item_number = intval(str_replace("ID", "", $info['ap_itemcode']));
					$item_name = $info['ap_itemname'];
					$payment_status = $info['ap_status'];
					$transaction_type = $info['ap_transactiontype'];
					$txn_id = $info['ap_referencenumber'];
					$seller_id = $info['ap_merchant'];
					$payer_id = $info['ap_custemailaddress'];
					$gross_total = $info['ap_totalamount'];
					$mc_currency = $info['ap_currency'];
					$payer_name = $info['ap_custfirstname'].' '.$info['ap_custlastname'];
					$payer_email = $info['apc_1'];

					if ($payment_status == "Success") {
						$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
						if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
						else {
							if (strtolower($seller_id) != strtolower($this->options['payza_id'])) $payment_status = "Unrecognized";
							else {
								if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized";
							}
						}
					}
					$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
						file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
						'".intval($item_number)."',
						'".esc_sql($payer_name)."',
						'".esc_sql($payer_id)."',
						'".floatval($gross_total)."',
						'".$mc_currency."',
						'".$payment_status."',
						'Payza: ".$transaction_type."',
						'".$txn_id."',
						'".esc_sql($response)."',
						'".time()."'
					)";
					$wpdb->query($sql);
					if ($payment_status == "Success") {
						$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
						$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
						$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

						$body = str_replace($tags, $vals, $this->options['success_email_body']);
						$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
						$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
						$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
						wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

						$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Payza on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
						$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
						$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
						$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
						wp_mail($this->options['seller_email'], __('Completed Payza payment received', 'paybox'), $body, $mail_headers);
					} else {
						$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
						$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

						$body = str_replace($tags, $vals, $this->options['failed_email_body']);
						$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
						$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
						$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
						wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

						$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Payza on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
						$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
						$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
						$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
						wp_mail($this->options['seller_email'], __('Non-completed Payza payment received', 'paybox'), $body, $mail_headers);
					}
				}
			}
			exit;
		} else if (isset($_REQUEST['paybox-ipn']) && $_REQUEST['paybox-ipn'] == 'skrill') {
			if (empty($_POST['pay_to_email']) || empty($_POST['pay_from_email'])) die();

			$response = "";
			foreach ($_POST as $key => $value) {
				$value = urlencode(stripslashes($value));
				$response .= "&".$key."=".$value;
			}

			$item_number = intval($_POST['file_id']);
			$txn_id = stripslashes($_POST['mb_transaction_id']);
			$seller_id = stripslashes($_POST['pay_to_email']);
			$payer_id = stripslashes($_POST['pay_from_email']);
			$payer_email = stripslashes($_POST['payer_email']);
			$gross_total = stripslashes($_POST['amount']);
			$mc_currency = stripslashes($_POST['currency']);
			$payment_status = stripslashes($_POST['status']);
			$transaction_type = "payment";
			$md5sig = stripslashes($_POST['md5sig']);
			$payer_name = stripslashes($_POST['pay_from_email']);

			if ($payment_status == 2) $payment_status = 'Completed';
			else if ($payment_status == 0) $payment_status = 'Pending';
			else if ($payment_status == -1) $payment_status = 'Cancelled';
			else if ($payment_status == -2) $payment_status = 'Failed';
			else if ($payment_status == -3) $payment_status = 'Chargeback';
			
			$hash = strtoupper(md5($_POST['merchant_id'].$_POST['transaction_id'].strtoupper(md5($this->options['skrill_secret_word'])).$_POST['mb_amount'].$_POST['mb_currency'].$_POST['status']));

			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
			if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
			else {
				if (strtolower($seller_id) != strtolower($this->options['skrill_id']) || $md5sig != $hash) $payment_status = "Unrecognized";
				else if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized";
			}

			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_id)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'Skrill: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($response)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			if ($payment_status == "Completed") {
				$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['success_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Skrill on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Completed Skrill payment received', 'paybox'), $body, $mail_headers);
			} else {
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['failed_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Skrill on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Non-completed Skrill payment received', 'paybox'), $body, $mail_headers);
			}
			exit;
		} else if (isset($_REQUEST['payboxipn']) && $_REQUEST['payboxipn'] == 'perfect') {
			if (empty($_POST['PAYMENT_ID']) || empty($_POST['PAYEE_ACCOUNT'])) die();
			$response = "";
			foreach ($_POST as $key => $value) {
				$value = urlencode(stripslashes($value));
				$response .= "&".$key."=".$value;
			}

			$str = $_POST['PAYMENT_ID'].':'.$_POST['PAYEE_ACCOUNT'].':'.
				$_POST['PAYMENT_AMOUNT'].':'.$_POST['PAYMENT_UNITS'].':'.
				$_POST['PAYMENT_BATCH_NUM'].':'.
				$_POST['PAYER_ACCOUNT'].':'.strtoupper(md5($this->options['perfect_passphrase'])).':'.
				$_POST['TIMESTAMPGMT'];

			$hash = strtoupper(md5($str));

			$item_number = intval($_POST['PAYMENT_ID']);
			$payment_status = "Completed";
			$transaction_type = "payment";
			$txn_id = stripslashes($_POST['PAYMENT_BATCH_NUM']);
			$seller_id = stripslashes($_POST['PAYEE_ACCOUNT']);
			$v2_hash = stripslashes($_POST['V2_HASH']);
			$gross_total = stripslashes($_POST['PAYMENT_AMOUNT']);
			$mc_currency = stripslashes($_POST['PAYMENT_UNITS']);
			$payer_name = stripslashes($_POST['PAYER_ACCOUNT']);
			$payer_id = stripslashes($_POST['email']);;
			$payer_email = stripslashes($_POST['email']);;

			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
			if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
			else {
				if ($v2_hash != $hash) $payment_status = "Invalid HASH";
				else if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"] || $seller_id != $this->options['perfect_account_id']) $payment_status = "Unrecognized";
			}

			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_id)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'PerfectMoney: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($response)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			if ($payment_status == "Completed") {
				$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['success_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via PerfectMoney on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Completed PerfectMoney payment received', 'paybox'), $body, $mail_headers);
			} else {
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['failed_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via PerfectMoney on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Non-completed PerfectMoney payment received', 'paybox'), $body, $mail_headers);
			}
			exit;
		} else if (isset($_REQUEST['paybox-ipn']) && $_REQUEST['paybox-ipn'] == 'bitpay') {
			$json = file_get_contents("php://input");
			if (empty($json)) die();
			
			$post = json_decode($json, true);
			if (!is_array($post)) die();
			
			$txn_id = stripslashes($post['id']);
			$curl = curl_init('https://bitpay.com/api/invoice/'.$txn_id);
			
			$header = array(
				'Content-Type: application/json',
				'Content-Length: 0',
				'Authorization: Basic '.base64_encode($this->options['bitpay_key']),
				);

			curl_setopt($curl, CURLOPT_PORT, 443);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
			curl_setopt($curl, CURLOPT_TIMEOUT, 10);
			curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ;
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
			curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
				
			$json = curl_exec($curl);

			curl_close($curl);
			
			if ($json === false) die();
			
			$post = json_decode($json, true);
			if (!$post) die();
			if (isset($post['error'])) die();
			
			$response = "";
			foreach ($post as $key => $value) {
				$value = urlencode(stripslashes($value));
				$response .= "&".$key."=".$value;
			}

			$posData = json_decode($post['posData'], true);

			$payment_status = stripslashes($post['status']);
			$item_number = intval($posData['file_id']);
			$payer_id = $posData['payer_email'];
			$payer_email = $posData['payer_email'];
			$transaction_type = "bitcoins";
			$payer_name = $posData['payer_email'];
			$mc_currency = $post['currency'];
			$gross_total = ($mc_currency == 'BTC' ? number_format($post['price'], 8, '.', '') : number_format($post['price'], 2, '.', ''));

			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
			if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
			else {
				if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized";
			}

			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_id)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'BitPay: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($response)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			if ($payment_status == "confirmed" || $payment_status == "complete") {
				$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['success_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via BitPay on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Completed BitPay payment received', 'paybox'), $body, $mail_headers);
			} else {
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['failed_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via BitPay on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Non-completed BitPay payment received', 'paybox'), $body, $mail_headers);
			}
			exit;
		} else if (isset($_REQUEST['paybox-ipn']) && $_REQUEST['paybox-ipn'] == 'interkassa') {
			if (isset($_POST['ik_co_id'])) {
				$request = '';
				$data = array();
				foreach ($_POST as $key => $value) {
					$request .= "&".$key."=".$value;
					if (strtolower(substr($key, 0, 3)) == 'ik_' && $key != 'ik_sign') $data[$key] = $value;
				}
				$item_number = $_POST['ik_pm_no'];
				if (($pos = strpos($item_number, "-")) !== false) $item_number = intval(substr($item_number, 0, $pos));
				$item_name = $_POST['ik_desc'];
				$payment_status = $_POST['ik_inv_st'];
				$transaction_type = $_POST['ik_pw_via'];
				$txn_id = $_POST['ik_co_prs_id'];
				$seller_id = $_POST['ik_co_id'];
				$payer_id = $_POST['ik_x_email'];
				$gross_total = $_POST['ik_am'];
				$mc_currency = $_POST['ik_cur'];
				$payer_name = $payer_id;

				if ($payment_status == "success") {
					$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
					if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized: N01";
					else if (strtolower($seller_id) != strtolower($this->options['interkassa_checkout_id'])) $payment_status = "Unrecognized: N02";
					else if (floatval($gross_total) < floatval($file_details["price"])) $payment_status = "Unrecognized: N03";
					else if (!empty($mc_currency) && $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized: N04";
					else {
						ksort($data, SORT_STRING);
						array_push($data, $this->options['interkassa_secret_key']);
						$signString = implode(':', $data);
						$sign = base64_encode(md5($signString, true));
						if ($_POST['ik_sign'] != $sign) $payment_status = "Unrecognized: N05";
					}
				}
				
				$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
					file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
					'".intval($item_number)."',
					'".esc_sql($payer_name)."',
					'".esc_sql($payer_id)."',
					'".floatval($gross_total)."',
					'".$mc_currency."',
					'".$payment_status."',
					'InterKassa: ".$transaction_type."',
					'".$txn_id."',
					'".esc_sql($request)."',
					'".time()."'
				)";
				$wpdb->query($sql);
				if ($payment_status == "success") {
					$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
					$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
					$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

					$body = str_replace($tags, $vals, $this->options['success_email_body']);
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($payer_id, $this->options['success_email_subject'], $body, $mail_headers);

					$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via InterKassa on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($this->options['seller_email'], __('Completed InterKassa payment received', 'paybox'), $body, $mail_headers);
				} else {
					$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
					$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

					$body = str_replace($tags, $vals, $this->options['failed_email_body']);
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($payer_id, $this->options['failed_email_subject'], $body, $mail_headers);

					$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via InterKassa on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($this->options['seller_email'], __('Non-completed InterKassa payment received', 'paybox'), $body, $mail_headers);
				}
			}
			exit;
		} else if (isset($_GET['paybox-ipn']) && $_GET['paybox-ipn'] == 'blockchain') {
			if (empty($_GET['transaction_hash']) || empty($_GET['secret'])) die();
			
			$response = 'operator=blockchain';
			foreach ($_GET as $key => $value) {
				if ($key == 'email') $value = base64_decode(trim(stripslashes($_GET['email'])));
				$response .= "&".$key."=".$value;
			}
			
			$item_number = intval($_GET['file_id']);
			$payer_id = base64_decode(trim(stripslashes($_GET['email'])));
			$payer_email = $payer_id;
			$transaction_type = "bitcoins";
			$payer_name = $payer_id;
			$gross_total = intval($_GET['value'])/100000000;
			$amount = floatval($_GET['amount']);
			$confirmations = intval($_GET['confirmations']);
			$txn_id = urldecode($_GET['transaction_hash']);
			$secret = urldecode($_GET['secret']);
			$mc_currency = 'BTC';
			$payment_status = "Confirmed";
			
			if ($confirmations < $this->options['blockchain_confirmations']) exit;

			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
			if (!$file_details) $payment_status = "Unrecognized N01";
			else {
				if (floatval($gross_total) < floatval($amount)) $payment_status = "Unrecognized N02";
				else if ($secret != $this->options['blockchain_secret']) $payment_status = "Unrecognized N03";
				else if (isset($_GET['test'])) $payment_status = "Test";
			}

			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_id)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'Blockchain: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($response)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			if ($payment_status == "Confirmed") {
				$download_link = $this->generate_downloadlink($file_details["id"], $payer_id, "payment");
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['success_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_id, $this->options['success_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via InterKassa on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Completed bitcoin (via Blockchain) payment received', 'paybox'), $body, $mail_headers);
			} else {
				if ($file_details) $file_title = $file_details["title"];
				else $file_title = 'Unknown File';
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
				$vals = array($payer_name, $payer_id, $file_title, $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['failed_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_id, $this->options['failed_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via InterKassa on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment status: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Non-completed InterKassa payment received', 'paybox'), $body, $mail_headers);
			}
			echo '*ok*';
			exit;
		} else if (isset($_GET['paybox-ipn']) && $_GET['paybox-ipn'] == 'stripe') {
			$payload = @file_get_contents('php://input');
			$post_data = json_decode($payload, true);
			if (empty($post_data) || !is_array($post_data) || !array_key_exists('type', $post_data) || $post_data['type'] != 'checkout.session.completed') {
				exit;
			}

			$id_parts = explode('-', $post_data['data']['object']['client_reference_id']);
			if (sizeof($id_parts) != 3) exit;
			if (empty($id_parts[2]) || $id_parts[2] != $this->options['stripe_webhook_uid']) exit;

			$response = "";
			foreach ($post_data as $key => $value) {
				if (is_array($value)) $value_sanitized = json_encode($value);
				else $value_sanitized = urlencode(stripslashes($value));
				$value_sanitized = str_replace('=', '-', $value_sanitized);
				$response .= "&".$key."=".$value_sanitized;
			}

			$item_number = intval($id_parts[0]);
			$payment_status = "Completed";
			$transaction_type = implode(', ', $post_data['data']['object']['payment_method_types']);
			$txn_id = $post_data['data']['object']['payment_intent'];
			$payer_id = $id_parts[1];
			$payer_email = $id_parts[1];
			$mc_currency = strtoupper($post_data['data']['object']['display_items'][0]['currency']);
			$gross_total = number_format($post_data['data']['object']['display_items'][0]['amount']/100, 2, '.', '');
			$payer_name = empty($post_data['data']['object']['customer']) ? 'Stripe Payer' : $post_data['data']['object']['customer'];
			$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
			
			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
			if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
			else {
				if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized";
				else {
					require_once(dirname(__FILE__).'/libs/stripe/init.php');
					try {
						\Stripe\Stripe::setApiKey($this->options['stripe_secret_key']);
						$event = \Stripe\Webhook::constructEvent($payload, $sig_header, $this->options['stripe_webhook_secret']);
					} catch(\UnexpectedValueException $e) {
						$payment_status = "Error: invalid payload";
					} catch(\Stripe\Error\SignatureVerification $e) {
						$payment_status = "Error: invalid signature";
					}							
				}
			}

			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_email)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'Stripe: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($response)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			
			if ($payment_status == "Completed") {
				$download_link = $this->generate_downloadlink($file_details["id"], $payer_paypal, "payment");
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
				$vals = array($payer_name, $payer_paypal, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['success_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Stripe on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Completed Stripe payment received', 'paybox'), $body, $mail_headers);
				http_response_code(200);
			} else {
				$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
				$vals = array($payer_name, $payer_paypal, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

				$body = str_replace($tags, $vals, $this->options['failed_email_body']);
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

				$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via Stripe on {transaction_date}. This is non-completed payment.', 'paybox').PHP_EOL.__('Payment ststus: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
				$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
				$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
				$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
				wp_mail($this->options['seller_email'], __('Non-completed Stripe payment received', 'paybox'), $body, $mail_headers);
			}
			exit;
		} else if (isset($_REQUEST['paybox-ipn'])) {
			$request = "cmd=_notify-validate";
			foreach ($_POST as $key => $value) {
				$value = urlencode(stripslashes($value));
				$request .= "&".$key."=".$value;
			}
			
			$paypalurl = 'https://www.paypal.com/cgi-bin/webscr';
			$ch = curl_init($paypalurl);
			curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close', 'User-Agent: Digital Paybox'));
			$result = curl_exec($ch);
			curl_close($ch);                
			if (substr(trim($result), 0, 8) != "VERIFIED") die();
			
			$item_number = stripslashes($_POST['item_number']);
			$item_name = stripslashes($_POST['item_name']);
			$payment_status = stripslashes($_POST['payment_status']);
			$transaction_type = stripslashes($_POST['txn_type']);
			$txn_id = stripslashes($_POST['txn_id']);
			$seller_paypal = stripslashes($_POST['business']);
			$seller_id = stripslashes($_POST['receiver_id']);
			$payer_paypal = stripslashes($_POST['payer_email']);
			$payer_email = stripslashes($_POST['custom']);
			$gross_total = stripslashes($_POST['mc_gross']);
			$mc_currency = stripslashes($_POST['mc_currency']);
			$payer_name = stripslashes($_POST['first_name']).' '.stripslashes($_POST['last_name']);

			$payer_status = stripslashes($_POST['payer_status']);
					
			if ($transaction_type == "web_accept" && $payment_status == "Completed") {
				$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($item_number)."'", ARRAY_A);
				if (intval($file_details["id"]) == 0) $payment_status = "Unrecognized";
				else {
					if (empty($seller_paypal)) {
						$tx_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_transactions WHERE details LIKE '%txn_id=".$txn_id."%' AND payment_status != 'Unrecognized'", ARRAY_A);
						if (intval($tx_details["id"]) != 0) $seller_paypal = $this->options['paypal_id'];
					}
					if ((strtolower($seller_paypal) != strtolower($this->options['paypal_id'])) && (strtolower($seller_id) != strtolower($this->options['paypal_id']))) $payment_status = "Unrecognized";
					else {
						if (floatval($gross_total) < floatval($file_details["price"]) || $mc_currency != $file_details["currency"]) $payment_status = "Unrecognized";
					}
				}
			}
			$sql = "INSERT INTO ".$wpdb->prefix."dd_transactions (
				file_id, payer_name, payer_email, gross, currency, payment_status, transaction_type, txn_id, details, created) VALUES (
				'".intval($item_number)."',
				'".esc_sql($payer_name)."',
				'".esc_sql($payer_paypal)."',
				'".floatval($gross_total)."',
				'".$mc_currency."',
				'".$payment_status."',
				'PayPal: ".$transaction_type."',
				'".$txn_id."',
				'".esc_sql($request)."',
				'".time()."'
			)";
			$wpdb->query($sql);
			if ($transaction_type == "web_accept") {
				if ($payment_status == "Completed") {
					$download_link = $this->generate_downloadlink($file_details["id"], $payer_paypal, "payment");
					$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
					$vals = array($payer_name, $payer_paypal, $file_details["title"], $gross_total, $mc_currency, $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");

					$body = str_replace($tags, $vals, $this->options['success_email_body']);
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($payer_email, $this->options['success_email_subject'], $body, $mail_headers);

					$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via PayPal on {transaction_date}. The buyer received the following download link:', 'paybox').PHP_EOL.'{download_link}'.PHP_EOL.__('This link is valid {download_link_lifetime} day(s) only.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($this->options['seller_email'], __('Completed PayPal payment received', 'paybox'), $body, $mail_headers);
				} else if ($payment_status == "Failed" || $payment_status == "Pending" || $payment_status == "Processed" || $payment_status == "Unrecognized") {
					$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{payment_status}", "{transaction_date}");
					$vals = array($payer_name, $payer_paypal, $file_details["title"], $gross_total, $mc_currency, $payment_status, date("Y-m-d H:i:s")." (server time)");

					$body = str_replace($tags, $vals, $this->options['failed_email_body']);
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($payer_email, $this->options['failed_email_subject'], $body, $mail_headers);

					$body = str_replace($tags, $vals, __('Dear Administrator!', 'paybox').PHP_EOL.PHP_EOL.__('We would like to inform you that {payer_name} ({payer_email}) paid {product_amount} {product_currency} for "{product_title}" via PayPal on {transaction_date}. This is non-completed paid.', 'paybox').PHP_EOL.__('Payment ststus: {payment_status}', 'paybox').PHP_EOL.PHP_EOL.__('Download link was not generated.', 'paybox').PHP_EOL.PHP_EOL.__('Thanks,', 'paybox').PHP_EOL.'Digital Paybox');
					$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
					$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
					$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
					wp_mail($this->options['seller_email'], __('Non-completed PayPal payment received', 'paybox'), $body, $mail_headers);
				}
			}
			exit;
		}
		add_action('wp_enqueue_scripts', array(&$this, 'front_enqueue_scripts'));
	}

	function front_header() {
		echo '
<script>
	var paybox_action = "'.admin_url('admin-ajax.php').'";
</script>';
	}

	function front_footer() {
		echo '
<script>
if (typeof paybox_init == "function") { 
	paybox_init();
} else {
	jQuery(document).ready(function(){paybox_init();});
}
</script>';
	}

	function shortcode_handler($_atts) {
		global $post, $wpdb, $current_user;
		$form = '';
		$options_stack = $this->options;
			$id = intval($_atts["id"]);
			$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$id."'", ARRAY_A);
			if (intval($file_details["id"]) == 0) return "";
			$sql = "SELECT COUNT(id) AS sales FROM ".$wpdb->prefix."dd_transactions WHERE file_id = '".$file_details["id"]."' AND (payment_status = 'Completed' OR payment_status = 'Success') AND deleted = '0'";
			$sales = $wpdb->get_row($sql, ARRAY_A);
			if (intval($sales["sales"]) < $file_details["available_copies"] || $file_details["available_copies"] == 0) {
				if (isset($_atts['gateways'])) {
					$this->options['enable_paypal'] = "off";
					$this->options['enable_perfect'] = "off";
					$this->options['enable_payza'] = "off";
					$this->options['enable_interkassa'] = "off";
					$this->options['enable_authnet'] = "off";
					$this->options['enable_skrill'] = "off";
					$this->options['enable_bitpay'] = "off";
					$gateways = explode(",", $_atts['gateways']);
					foreach ($gateways as $gateway) {
						if (isset($this->options['enable_'.$gateway])) $this->options['enable_'.$gateway] = "on";
					}
				}
				if (!in_array($file_details['currency'], $this->blockchain_currency_list)) $this->options['enable_blockchain'] = "off";
				if (!in_array($file_details["currency"], $this->interkassa_currency_list)) $this->options['enable_interkassa'] = "off";
				if (!in_array($file_details["currency"], $this->paypal_currency_list)) $this->options['enable_paypal'] = "off";
				if (!in_array($file_details["currency"], $this->perfect_currency_list)) $this->options['enable_perfect'] = "off";
				if (!in_array($file_details["currency"], $this->payza_currency_list)) $this->options['enable_payza'] = "off";
				if (!in_array($file_details["currency"], $this->skrill_currency_list)) $this->options['enable_skrill'] = "off";
				if (!in_array($file_details["currency"], $this->bitpay_currency_list)) $this->options['enable_bitpay'] = "off";
				if (!in_array($file_details["currency"], $this->stripe_currency_list)) $this->options['enable_stripe'] = "off";
				if ($file_details["currency"] != 'USD') $this->options['enable_authnet'] = "off";
				$methods = 0;
				if ($this->options['enable_paypal'] == "on") $methods++;
				if ($this->options['enable_perfect'] == "on") $methods++;
				if ($this->options['enable_payza'] == "on") $methods++;
				if ($this->options['enable_interkassa'] == "on") $methods++;
				if ($this->options['enable_authnet'] == "on") $methods++;
				if ($this->options['enable_skrill'] == "on") $methods++;
				if ($this->options['enable_bitpay'] == "on") $methods++;
				if ($this->options['enable_stripe'] == "on") $methods++;
				if ($this->options['enable_blockchain'] == "on") $methods++;
				//if ($methods == 0) return '';
				if (($file_details['price'] > 0 || $file_details["fixed_price"] != 1) && $methods == 0) return '';
			
				$return_url = "";
				if (!empty($_atts["return_url"])) {
					$return_url = $_atts["return_url"];
					if (!preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $return_url) || strlen($return_url) == 0) $return_url = "";
				}
				if (empty($return_url)) {
					if (defined('UAP_CORE')) $return_url = $_SERVER["HTTP_REFERER"];
					else $return_url = (empty($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] == 'off' ? 'http://' : 'https://').$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
				}
				
				$gdpr_html = '';
				if ($this->options['gdpr_enable'] == 'on') {
					$gdpr_id = $this->random_string(8);
					$checkbox_html = '<div class="paybox-checkbox"><input type="checkbox" id="'.$gdpr_id.'" name="paybox-gdpr" value="off"><label for="'.$gdpr_id.'"></label></div>';
					preg_match("'{(.*?)}'si", $this->options['gdpr_title'], $match);
					$local_terms_title = '';
					if ($match) $local_terms_title = $match[1];
					if (strlen($local_terms_title) > 0) {
						$terms = esc_html($this->options['terms']);
						$terms = str_replace("\n", "<br />", $terms);
						$terms = str_replace("\r", "", $terms);
						$gdpr_title = str_replace('{'.$local_terms_title.'}', '<a href="#" onclick="jQuery(this).parent().find(\'.paybox-terms-container\').slideToggle(300); return false;">'.$local_terms_title.'</a>', $this->options['gdpr_title']);
						$gdpr_html = '
							<div class="paybox-row">
								'.$checkbox_html.$gdpr_title.'
								<div class="paybox-terms-container paybox-hide">
									<div class="paybox-terms">'.$terms.'</div>
								</div>
							</div>';
					} else {
						$gdpr_html = '
							<div class="paybox-row">
							'.$checkbox_html.$this->options['gdpr_title'].'
							</div>';
					}
				}
				
				if (isset($_atts["title"])) $intro = do_shortcode(trim($_atts["title"]));
				else $intro = do_shortcode($file_details['intro']);
				$tags = array("{min_amount}", "{currency}");
				$vals = array($file_details['price'], $file_details['currency']);
				$intro = str_replace($tags, $vals, $intro);
				if (strlen($intro) > 0) $intro = '<div class="paybox-row paybox-description">'.$intro.'</div>';
				
				if ($this->options['enable_paypal'] == "on") $active_method = 'paypal';
				else if ($this->options['enable_perfect'] == "on") $active_method = 'perfect';
				else if ($this->options['enable_payza'] == "on") $active_method = 'payza';
				else if ($this->options['enable_interkassa'] == "on") $active_method = 'interkassa';
				else if ($this->options['enable_authnet'] == "on") $active_method = 'authnet';
				else if ($this->options['enable_skrill'] == "on") $active_method = 'skrill';
				else if ($this->options['enable_bitpay'] == "on") $active_method = 'bitpay';
				else if ($this->options['enable_blockchain'] == "on") $active_method = 'blockchain';
				else if ($this->options['enable_stripe'] == "on") $active_method = 'stripe';
				
				$form = '
<div class="paybox-mainbox">
	<div class="paybox-payment-form">
		'.$intro.'
		'.($file_details["fixed_price"] == 1 ? '
		<div class="paybox-row">
			<input class="paybox-input" name="paybox-email" type="text" placeholder="'.__('Your e-mail address (mandatory)', 'paybox').'" />
			<input type="hidden" name="paybox-amount" value="'.$file_details['price'].'" />
		</div>' : '
		<div class="paybox-row paybox-table">
			<div class="paybox-table-cell paybox-table-cell-100">
				<input class="paybox-input" name="paybox-email" type="text" placeholder="'.__('Your e-mail address (mandatory)', 'paybox').'">
			</div>
			<div class="paybox-table-cell">
				<input class="paybox-input paybox-input-number" name="paybox-amount" type="text" placeholder="'.$file_details["currency"].'">
			</div>
		</div>');
				if ($file_details['price'] > 0 || $file_details["fixed_price"] != 1) {
					$form .= '
		<div class="paybox-row paybox-table">
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-payment-seclector">
					<div class="paybox-payment-selected" onclick="jQuery(this).parent().children(\'.paybox-payment-providers\').slideToggle(200);" style="background-image: url('.plugins_url('/images/logo_'.$active_method.'.png', __FILE__).');">
						<span>▼</span>
					</div>
					<div class="paybox-payment-providers'.($methods > 4 ? ' paybox-vertical-scroll' : '').'">';
					if ($this->options['enable_paypal'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'paypal\');" style="background-image: url('.plugins_url('/images/logo_paypal.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_paypal.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_payza'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'payza\');" style="background-image: url('.plugins_url('/images/logo_payza.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_payza.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_skrill'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'skrill\');" style="background-image: url('.plugins_url('/images/logo_skrill.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_skrill.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_interkassa'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'interkassa\');" style="background-image: url('.plugins_url('/images/logo_interkassa.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_interkassa.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_authnet'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'authnet\');" style="background-image: url('.plugins_url('/images/logo_authnet.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_authnet.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_bitpay'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'bitpay\');" style="background-image: url('.plugins_url('/images/logo_bitpay.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_bitpay.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_blockchain'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'blockchain\');" style="background-image: url('.plugins_url('/images/logo_blockchain.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_blockchain.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_perfect'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'perfect\');" style="background-image: url('.plugins_url('/images/logo_perfect.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_perfect.png', __FILE__).'"></a>';
					}
					if ($this->options['enable_stripe'] == "on") {
						$form .= '
						<a href="#" onclick="return paybox_set_provider(this, \'stripe\');" style="background-image: url('.plugins_url('/images/logo_stripe.png', __FILE__).');" data-logo="'.plugins_url('/images/logo_stripe.png', __FILE__).'"></a>';
					}
					$form .= '
					</div>
				</div>
			</div>
			<div class="paybox-table-cell">
				<a class="paybox-button" href="#" onclick="return paybox_continue(this);">'.__('Continue', 'paybox').'</a>
			</div>
		</div>';
				} else {
					$form .= '
		<div class="paybox-row paybox-table">
			<a class="paybox-button" href="#" onclick="return paybox_continue(this);">'.__('Continue', 'paybox').'</a>
		</div>';
				}
				$form .= $gdpr_html.'
		<input type="hidden" name="paybox-gateway" value="'.$active_method.'" />
		<input type="hidden" name="paybox-file" value="'.$file_details['id'].'" />
		<input type="hidden" name="paybox-return" value="'.$return_url.'" />
	</div>
	<div class="paybox-confirmation"></div>
	<div class="paybox-error"></div>
	<div class="paybox-loading-overlay"></div>
	<div class="paybox-loading-spinner"></div>
</div>';
		}
		$this->options = $options_stack;
		return $form;
	}

	function paybox_continue() {
		global $wpdb;
		if (isset($_REQUEST['callback'])) {
			header("Content-type: text/javascript");
			$jsonp_enabled = true;
			$jsonp_callback = $_REQUEST['callback'];
		} else exit;	
		if (isset($_REQUEST['email'])) $email = base64_decode(trim(stripslashes($_REQUEST['email'])));
		else $email = '';
		if (isset($_REQUEST['amount'])) $amount = floatval(base64_decode(trim(stripslashes($_REQUEST['amount']))));
		else $amount = 0;
		if (isset($_REQUEST['gateway'])) $payment_method = base64_decode(trim(stripslashes($_REQUEST['gateway'])));
		else $payment_method = '';
		if (isset($_REQUEST['file'])) $file_id = intval(base64_decode(trim(stripslashes($_REQUEST['file']))));
		else $file_id = 0;
		if (isset($_REQUEST['return'])) $return_url = base64_decode(trim(stripslashes($_REQUEST['return'])));
		else $return_url = '';
		if (isset($_REQUEST['gdpr'])) $gdpr = base64_decode(trim(stripslashes($_REQUEST['gdpr'])));
		else $gdpr = 'off';
		
		if (empty($return_url)) $return_url = $_SERVER["HTTP_REFERER"];
		
		$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$file_id."' AND deleted = '0'", ARRAY_A);
		
		$errors = array();
		if (intval($file_details["id"]) == 0) $errors[] = __('Invalid file.', 'paybox');
		if (empty($email)) $errors[] = __('Your e-mail address is required.', 'paybox');
		else if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $email)) $errors[] = __('You have entered an invalid e-mail address.', 'paybox');
		if (!is_numeric($amount) || $amount < $file_details['price']) $errors[] = __('Amount must be at least', 'paybox').' '.($file_details['currency'] == 'BTC' ? number_format($file_details['price'], 8, ".", "") : number_format($file_details['price'], 2, ".", "")).' '.$file_details['currency'].'.';
		if ($payment_method == 'interkassa' && $this->options['enable_interkassa'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'payza' && $this->options['enable_payza'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'authnet' && $this->options['enable_authnet'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'skrill' && $this->options['enable_skrill'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'bitpay' && $this->options['enable_bitpay'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'blockchain' && $this->options['enable_blockchain'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'stripe' && $this->options['enable_stripe'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'perfect' && $this->options['enable_perfect'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		else if ($payment_method == 'paypal' && $this->options['enable_paypal'] != 'on') $errors[] = __('Payment method not supported.', 'paybox');
		if ($this->options['gdpr_enable'] == 'on' && $gdpr != 'on') $errors[] = $this->options['gdpr_error_label'];
		
		if (!empty($errors)) {
			$return_data = array();
			$return_data['status'] = 'ERROR';
			$return_data['html'] = implode('<br />', $errors);
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		} else {
			$html = '';
			if ($amount == 0) {
				$html .= '
		<div class="paybox-row paybox-row-dashed paybox-table">
			<div class="paybox-table-cell">
				<div class="paybox-confirmation-label">'.__('E-Mail', 'paybox').':</div>
			</div>
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-confirmation-value">'.esc_html($email).'</div>
			</div>
		</div>
		<div class="paybox-row">
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_getlink(this);">'.__('Get Download Link', 'paybox').'</a>
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_edit(this);">'.__('Edit Info', 'paybox').'</a>
		</div>';			
			} else {
				if ($file_details['currency'] == 'BTC') $amount = number_format($amount, 8, ".", "");
				else $amount = number_format($amount, 2, ".", "");
				$html .= '
		<div class="paybox-row paybox-row-dashed paybox-table">
			<div class="paybox-table-cell">
				<div class="paybox-confirmation-label">'.__('Product', 'paybox').':</div>
			</div>
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-confirmation-value">'.esc_html($file_details['title']).'</div>
			</div>
		</div>
		<div class="paybox-row paybox-row-dashed paybox-table">
			<div class="paybox-table-cell">
				<div class="paybox-confirmation-label">'.__('E-Mail', 'paybox').':</div>
			</div>
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-confirmation-value">'.esc_html($email).'</div>
			</div>
		</div>
		<div class="paybox-row paybox-row-dashed paybox-table">
			<div class="paybox-table-cell">
				<div class="paybox-confirmation-label">'.__('Amount', 'paybox').':</div>
			</div>
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-confirmation-value">'.$amount.' '.$file_details['currency'].'</div>
			</div>
		</div>
		<div class="paybox-row paybox-row-dashed paybox-table">
			<div class="paybox-table-cell">
				<div class="paybox-confirmation-label">'.__('Payment gateway', 'paybox').':</div>
			</div>
			<div class="paybox-table-cell paybox-table-cell-100">
				<div class="paybox-confirmation-value"><img src="'.plugins_url('/images/logo_'.$payment_method.'.png', __FILE__).'" alt="'.esc_html($file_details['title']).'" /></div>
			</div>
		</div>
		<div class="paybox-row">';
				if ($payment_method == 'bitpay') {
					$html .= '
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_bitpay(this);">'.__('Confirm And Pay', 'paybox').'</a>
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_edit(this);">'.__('Edit Info', 'paybox').'</a>';
				} else if ($payment_method == 'blockchain') {
					$html .= '
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_blockchain(this);">'.__('Confirm And Pay', 'paybox').'</a>
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_edit(this);">'.__('Edit Info', 'paybox').'</a>';
				} else if ($payment_method == 'stripe') {
					$session_id = 0;
					require_once(dirname(__FILE__).'/libs/stripe/init.php');
					try {
						\Stripe\Stripe::setApiKey($this->options['stripe_secret_key']);
						$stripe_session = \Stripe\Checkout\Session::create([
							'success_url' => $return_url,
							'cancel_url' => $_SERVER["HTTP_REFERER"],
							'payment_method_types' => ['card'],
							'client_reference_id' => $file_details["id"].'-'.$email.'-'.$this->options['stripe_webhook_uid'],
							'line_items' => [
								[
									'amount' => intval($amount*100),
									'currency' => $file_details["currency"],
									'name' => (!empty($file_details["title"]) ? $file_details["title"] : 'Fee'),
									'quantity' => 1,
								],
							],
						]);
						$session_id = $stripe_session->id;
					} catch(Exception $e) {
						$body = $e->getJsonBody();
						$return_data['status'] = 'ERROR';
						$return_data['html'] = rtrim($body['error']['message'], '.').'.';
						echo $jsonp_callback.'('.json_encode($return_data).')';
						exit;
					}
					$html .= '
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_stripe_checkout(this);" data-public-key="'.esc_html($this->options['stripe_public_key']).'" data-session-id="'.esc_html($session_id).'">'.__('Confirm And Pay', 'paybox').'</a>
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_edit(this);">'.__('Edit Info', 'paybox').'</a>';
				} else {
					$html .= '
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_pay(this);">'.__('Confirm And Pay', 'paybox').'</a>
			<a class="paybox-button paybox-button-small" href="#" onclick="return paybox_edit(this);">'.__('Edit Info', 'paybox').'</a>';
				}
				$html .= '
		</div>';
				if ($payment_method == 'interkassa') {
					$params = array();
					$params['ik_co_id'] = $this->options['interkassa_checkout_id'];
					$params['ik_am'] = number_format($amount, 2, ".", "");
					$params['ik_cur'] = $file_details["currency"];
					$params['ik_pm_no'] = $file_details["id"].'-'.time();
					$params['ik_desc'] = esc_html($file_details["title"]);
					$params['ik_ia_u'] = defined('UAP_CORE') ? admin_url('do.php').'?paybox-ipn=interkassa' : get_bloginfo("url").'/?paybox-ipn=interkassa';
					$params['ik_ia_m'] = 'POST';
					$params['ik_suc_u'] = $return_url;
					$params['ik_suc_m'] = 'GET';
					$params['ik_fal_u'] = $_SERVER["HTTP_REFERER"];
					$params['ik_fal_m'] = 'GET';
					$params['ik_x_email'] = $email;
					$html .= '
	<form action="https://sci.interkassa.com/" method="post" target="_top" style="display:none;">';
					foreach($params as $key => $value) {
						$html .= '
		<input type="hidden" name="'.$key.'" value="'.$value.'">';
					}
					$html .= '
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				} else if ($payment_method == 'payza') {
					$html .= '
	<form action="'.($this->options['payza_sandbox'] == 'on' ? 'https://sandbox.payza.com/sandbox/payprocess.aspx' : 'https://secure.payza.com/PayProcess.aspx').'" method="post" target="_top" style="display:none;">
		<input type="hidden" name="ap_merchant" value="'.$this->options['payza_id'].'">
		<input type="hidden" name="ap_purchasetype" value="item">
		<input type="hidden" name="ap_itemname" value="'.esc_html($file_details['title']).'">
		<input type="hidden" name="ap_amount" value="'.$amount.'">
		<input type="hidden" name="ap_currency" value="'.$file_details["currency"].'">
		<input type="hidden" name="apc_1" value="'.$email.'">
		<input type="hidden" name="ap_itemcode" value="ID'.$file_details["id"].'">
		<input type="hidden" name="ap_returnurl" value="'.$return_url.'">
		<input type="hidden" name="ap_cancelurl" value="'.$_SERVER["HTTP_REFERER"].'">
		<input type="hidden" name="ap_alerturl" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-ipn=payza') : esc_html(get_bloginfo('url').'/?paybox-ipn=payza')).'">
		<input type="hidden" name="ap_ipnversion" value="2">
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				} else if ($payment_method == 'authnet') {
					$headers = array(
						'Content-Type: application/json;charset=UTF-8',
						'Accept: application/json'
					);
					$post_data = array(
						'getHostedPaymentPageRequest' => array(
							'merchantAuthentication' => array(
								'name' => $this->options['authnet_login_id'],
								'transactionKey' => $this->options['authnet_transaction_key']
							),
							'refId' => $this->options['authnet_webhook_uid'].'-'.$file_details["id"],
							'transactionRequest' => array(
								'transactionType' => 'authCaptureTransaction',
								'amount' => $amount,
								'customer' => array(
									'email' => $email
								)
							),
							'hostedPaymentSettings' => array(
								'setting' => array(
									array(
										'settingName' => 'hostedPaymentReturnOptions',
										'settingValue' => json_encode(array(
											'showReceipt' => true,
											'url' => $return_url,
											'urlText' => __('Continue', 'paybox'),
											'cancelUrl' => $_SERVER["HTTP_REFERER"],
											'cancelUrlText' => __('Cancel', 'paybox'),
										))
									),
									array(
										'settingName' => 'hostedPaymentBillingAddressOptions',
										'settingValue' => json_encode(array(
											'show' => false,
											'required' => false
										))
									),
									array(
										'settingName' => 'hostedPaymentCustomerOptions',
										'settingValue' => json_encode(array(
											'showEmail' => false,
											'requiredEmail' => false,
											'addPaymentProfile' => false
										))
									)
								)
							)
						)
					);
					$result = null;
					try {
						$url = ($this->options['authnet_sandbox'] == "on") ? 'https://apitest.authorize.net/xml/v1/request.api' : 'https://api.authorize.net/xml/v1/request.api';
						$curl = curl_init($url);
						curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($curl, CURLOPT_POST, true);
						curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($post_data));
						curl_setopt($curl, CURLOPT_TIMEOUT, 20);
						curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($curl, CURLOPT_FORBID_REUSE, true);
						curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
						curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
						curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
						$response = curl_exec($curl);
						curl_close($curl);
						$result = json_decode(preg_replace('/^'.pack('H*','EFBBBF').'/', '', $response), true);
					} catch (Exception $e) {
						$result = null;
					}
					if (empty($result)) {
						$return_data = array('status' => 'ERROR', 'html' => __('Can not connect to Authorize.net server.', 'paybox'));
						echo $jsonp_callback.'('.json_encode($return_data).')';
						exit;
					}
					if (array_key_exists('token', $result)) {
						$token = $result['token'];
					} else if (array_key_exists('messages', $result) && is_array($result['messages']) && array_key_exists('message', $result['messages']) && is_array($result['messages']['message'])) {
						$return_data = array('status' => 'ERROR', 'html' => $result['messages']['message'][0]['text']);
						echo $jsonp_callback.'('.json_encode($return_data).')';
						exit;
					} else {
						$return_data = array('status' => 'ERROR', 'html' => __('Invalid response from Authorize.net server.', 'paybox'));
						echo $jsonp_callback.'('.json_encode($return_data).')';
						exit;
					}
					$html .= '
	<form action="'.(($this->options['authnet_sandbox'] == "on") ? 'https://test.authorize.net/payment/payment' : 'https://accept.authorize.net/payment/payment').'" method="post" target="_top" style="display:none;">
		<input type="hidden" name="token" value="'.esc_html($token).'">
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				} else if ($payment_method == 'skrill') {
					$html .= '
	<form action="https://www.moneybookers.com/app/payment.pl" method="post" target="_top" style="display:none;">
		<input type="hidden" name="pay_to_email" value="'.$this->options['skrill_id'].'">
		<input type="hidden" name="return_url" value="'.$return_url.'">
		<input type="hidden" name="cancel_url" value="'.$_SERVER["HTTP_REFERER"].'">
		<input type="hidden" name="status_url" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-ipn=skrill') : esc_html(get_bloginfo("url").'/?paybox-ipn=skrill')).'">
		<input type="hidden" name="language" value="EN">
		<input type="hidden" name="amount" value="'.number_format($amount, 2, ".", "").'">
		<input type="hidden" name="currency" value="'.$file_details["currency"].'">
		<input type="hidden" name="detail1_description" value="'.__('Payment:', 'paybox').'">
		<input type="hidden" name="detail1_text" value="'.esc_html($file_details["title"]).'">
		<input type="hidden" name="merchant_fields" value="file_id,payer_email">
		<input type="hidden" name="file_id" value="'.$file_details["id"].'">
		<input type="hidden" name="payer_email" value="'.$email.'">
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				} else if ($payment_method == 'bitpay') {
				} else if ($payment_method == 'blockchain') {
				} else if ($payment_method == 'stripe') {
				} else if ($payment_method == 'perfect')  {
					$html .= '
	<form action="https://perfectmoney.is/api/step1.asp" method="post" target="_top" style="display:none;">
		<input type="hidden" name="PAYEE_ACCOUNT" value="'.$this->options['perfect_account_id'].'">
		<input type="hidden" name="PAYEE_NAME" value="'.$this->options['perfect_payee_name'].'">
		<input type="hidden" name="PAYMENT_AMOUNT" value="'.$amount.'">
		<input type="hidden" name="PAYMENT_UNITS" value="'.$file_details['currency'].'">
		<input type="hidden" name="SUGGESTED_MEMO" value="'.esc_html($file_details['title']).'">
		<input type="hidden" name="SUGGESTED_MEMO_NOCHANGE" value="1">
		<input type="hidden" name="PAYMENT_ID" value="'.$file_details["id"].'">
		<input type="hidden" name="PAYMENT_URL" value="'.$return_url.'">
		<input type="hidden" name="PAYMENT_URL_METHOD" value="LINK">
		<input type="hidden" name="NOPAYMENT_URL" value="'.$_SERVER["HTTP_REFERER"].'">
		<input type="hidden" name="NOPAYMENT_URL_METHOD" value="LINK">
		<input type="hidden" name="STATUS_URL" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-ipn=perfect') : esc_html(get_bloginfo('url').'/?paybox-ipn=perfect')).'">
		<input type="hidden" name="BAGGAGE_FIELDS" value="payboxipn email">
		<input type="hidden" name="payboxipn" value="perfect">
		<input type="hidden" name="email" value="'.$email.'">
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				} else {
					$html .= '
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top" style="display: none;">
		<input type="hidden" name="cmd" value="_xclick">
		<input type="hidden" name="charset" value="utf-8">					
		<input type="hidden" name="business" value="'.$this->options['paypal_id'].'">
		<input type="hidden" name="no_shipping" value="1">
		<input type="hidden" name="rm" value="2">
		<input type="hidden" name="item_name" value="'.esc_html($file_details['title']).'">
		<input type="hidden" name="item_number" value="'.$file_details["id"].'">
		<input type="hidden" name="amount" value="'.$amount.'">
		<input type="hidden" name="currency_code" value="'.$file_details["currency"].'">
		<input type="hidden" name="custom" value="'.$email.'">
		<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest">
		<input type="hidden" name="return" value="'.$return_url.'">
		<input type="hidden" name="cancel_return" value="'.$_SERVER["HTTP_REFERER"].'">
		<input type="hidden" name="notify_url" value="'.(defined('UAP_CORE') ? esc_html(admin_url('do.php').'?paybox-ipn=paypal') : esc_html(get_bloginfo('url').'/?paybox-ipn=paypal')).'">
		<input type="submit" class="paybox-pay" value="Submit">
	</form>';
				}
			}
			$return_data = array();
			$return_data['status'] = 'OK';
			$return_data['html'] = $html;
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		}
		exit;
	}

	function paybox_getblockchainaddress() {
		global $wpdb;
		if (isset($_REQUEST['callback'])) {
			header("Content-type: text/javascript");
			$jsonp_enabled = true;
			$jsonp_callback = $_REQUEST['callback'];
		} else exit;		
		if (isset($_REQUEST['email'])) $email = base64_decode(trim(stripslashes($_REQUEST['email'])));
		else $email = '';
		if (isset($_REQUEST['amount'])) $amount = floatval(base64_decode(trim(stripslashes($_REQUEST['amount']))));
		else $amount = 0;
		if (isset($_REQUEST['file'])) $file_id = intval(base64_decode(trim(stripslashes($_REQUEST['file']))));
		else $file_id = 0;

		$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$file_id."' AND deleted = '0'", ARRAY_A);
		
		$errors = array();
		if (intval($file_details["id"]) == 0) $errors[] = __('Invalid file.', 'paybox');
		if (empty($email)) $errors[] = __('Your e-mail address is required.', 'paybox');
		else if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $email)) $errors[] = __('You have entered an invalid e-mail address.', 'paybox');
		if (!is_numeric($amount) || $amount < $file_details['price']) $errors[] = __('Amount must be at least', 'paybox').' '.number_format($file_details['price'], 2, ".", "").' '.$file_details['currency'].'.';
		
		if (empty($errors)) {
			$btc_amount = $amount;
			if ($file_details['currency'] != 'BTC') {
				$curl = curl_init('https://blockchain.info/tobtc?currency='.$file_details['currency'].'&value='.number_format($amount, 2, ".", ""));
				curl_setopt($curl, CURLOPT_POST, false);
				curl_setopt($curl, CURLOPT_TIMEOUT, 20);
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($curl, CURLOPT_FORBID_REUSE, true);
				curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
				curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
				curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
				$btc_amount = curl_exec($curl);
				curl_close($curl);
				if (is_numeric($btc_amount)) {
					$btc_amount = number_format(floatval($btc_amount), 8, ".", "");
				}
				if ($btc_amount == 0) {
					$return_data = array();
					$return_data['status'] = 'ERROR';
					$return_data['html'] = __('Unable to convert amount into BTC. Try again later.', 'paybox');
					echo $jsonp_callback.'('.json_encode($return_data).')';
					exit;
				}
			}
			$callback_base = defined('UAP_CORE') ? admin_url('do.php') : get_bloginfo('url').'/';
			$url = 'https://api.blockchain.info/v2/receive?xpub='.$this->options['blockchain_xpub'].'&callback='.urlencode($callback_base.'?paybox-ipn=blockchain&file_id='.$file_id.'&email='.base64_encode($email).'&btc_amount='.number_format($btc_amount, 8, ".", "").'&amount='.number_format($btc_amount, 8, ".", "").'&secret='.$this->options['blockchain_secret']).'&key='.$this->options['blockchain_api_key'].'&gap_limit=1000';
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_POST, false);
			curl_setopt($curl, CURLOPT_TIMEOUT, 20);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_FORBID_REUSE, true);
			curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
				
			$json = curl_exec($curl);
			curl_close($curl);
			if ($json === false) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = __('Payment gateway is not available now (error 1). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			$post = json_decode($json, true);
			if (!$post) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = __('Payment gateway is not available now (error 2). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			if (!array_key_exists('address', $post)) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				if (array_key_exists('description', $post)) $return_data['html'] = ucfirst($post['description']);
				else if (array_key_exists('message', $post)) $return_data['html'] = ucfirst($post['message']);
				else $return_data['html'] = __('Payment gateway is not available now (error 3). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			$return_data = array();
			$return_data['status'] = 'OK';
			$return_data['html'] = '
					<div class="paybox-row paybox-center paybox-margin-top-10 paybox-blockchain-ok">
						'.sprintf(__('Please send <strong>%s</strong> BTC to the following address to complete transaction:<br /><br /><strong>%s</strong>', 'paybox'), number_format($btc_amount, 8, ".", ""), $post['address']).'
					</div>';
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		} else {
			$return_data = array();
			$return_data['status'] = 'ERROR';
			$return_data['html'] = implode('<br />', $errors);
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		}
		exit;
	}

	function paybox_sendlink() {
		global $wpdb;
		if (isset($_REQUEST['callback'])) {
			header("Content-type: text/javascript");
			$jsonp_enabled = true;
			$jsonp_callback = $_REQUEST['callback'];
		} else exit;		
		if (isset($_REQUEST['email'])) $email = base64_decode(trim(stripslashes($_REQUEST['email'])));
		else $email = '';
		if (isset($_REQUEST['file'])) $file_id = intval(base64_decode(trim(stripslashes($_REQUEST['file']))));
		else $file_id = 0;

		$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$file_id."' AND deleted = '0'", ARRAY_A);
		$errors = array();
		if (intval($file_details["id"]) == 0 || $file_details["price"] > 0) $errors[] = __('Invalid file.', 'paybox');
		if (empty($email)) $errors[] = __('Your e-mail address is required.', 'paybox');
		else if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $email)) $errors[] = __('You have entered an invalid e-mail address.', 'paybox');
		
		if (empty($errors)) {
			$download_link = $this->generate_downloadlink($file_details["id"], $email, "free");
			$tags = array("{payer_name}", "{payer_email}", "{product_title}", "{product_amount}", "{product_currency}", "{download_link}", "{download_link_lifetime}", "{transaction_date}");
			$vals = array(__('Visitor', 'paybox'), $email, $file_details["title"], '0.00', $file_details["currency"], $download_link ,$this->options['link_lifetime'], date("Y-m-d H:i:s")." (server time)");
			$body = str_replace($tags, $vals, $this->options['success_email_body']);
			$mail_headers = "Content-Type: text/plain; charset=utf-8\r\n";
			$mail_headers .= "From: ".$this->options['from_name']." <".$this->options['from_email'].">\r\n";
			$mail_headers .= "X-Mailer: PHP/".phpversion()."\r\n";
			wp_mail($email, $this->options['success_email_subject'], $body, $mail_headers);
			$return_data = array();
			$return_data['status'] = 'OK';
			$return_data['html'] = '<div style="text-align: center;">'.__('Download link was sent to', 'paybox').' <strong>'.esc_html($email).'</strong>.</div>';
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		} else {
			$return_data = array();
			$return_data['status'] = 'ERROR';
			$return_data['html'] = implode('<br />', $errors);
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		}
		exit;
	}

	function paybox_getbitpayurl() {
		global $wpdb;
		if (isset($_REQUEST['callback'])) {
			header("Content-type: text/javascript");
			$jsonp_enabled = true;
			$jsonp_callback = $_REQUEST['callback'];
		} else exit;		
		if (isset($_REQUEST['email'])) $email = base64_decode(trim(stripslashes($_REQUEST['email'])));
		else $email = '';
		if (isset($_REQUEST['amount'])) $amount = floatval(base64_decode(trim(stripslashes($_REQUEST['amount']))));
		else $amount = 0;
		if (isset($_REQUEST['file'])) $file_id = intval(base64_decode(trim(stripslashes($_REQUEST['file']))));
		else $file_id = 0;
		
		$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".$file_id."' AND deleted = '0'", ARRAY_A);
		
		$errors = array();
		if (intval($file_details["id"]) == 0) $errors[] = __('Invalid file.', 'paybox');
		if (empty($email)) $errors[] = __('Your e-mail address is required.', 'paybox');
		else if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,19})$/i", $email)) $errors[] = __('You have entered an invalid e-mail address.', 'paybox');
		if (!is_numeric($amount) || $amount < $file_details['price']) $errors[] = __('Amount must be at least', 'paybox').' '.number_format($file_details['price'], 2, ".", "").' '.$file_details['currency'].'.';

		if (empty($error)) {
			$options['orderID'] = $file_details['id'].'N'.time();
			$options['itemDesc'] = $file_details['title'];
			$options['itemCode'] = $file_details['id'];
			$options['notificationURL'] = defined('UAP_CORE') ? admin_url('do.php').'?paybox-ipn=bitpay' : get_bloginfo('url').'/?paybox-ipn=bitpay';
			$options['price'] = ($file_details['currency'] == 'BTC' ? number_format($amount, 8, ".", "") : number_format($amount, 2, ".", ""));
			$options['currency'] = $file_details['currency'];
			$options['physical'] = 'false';
			$options['transactionSpeed'] = $this->options['bitpay_speed'];
			$options['fullNotifications'] = 'false';
			$options['posData'] = '{"file_id" : "'.$file_details['id'].'", "payer_email" : "'.$email.'"}';

			$post = json_encode($options);

			$curl = curl_init('https://bitpay.com/api/invoice/');
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
			
			$header = array(
				'Content-Type: application/json',
				'Content-Length: '.strlen($post),
				'Authorization: Basic '.base64_encode($this->options['bitpay_key']),
				);

			//curl_setopt($curl, CURLOPT_PORT, 443);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
			curl_setopt($curl, CURLOPT_TIMEOUT, 10);
			curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC ) ;
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // verify certificate
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0); // check existence of CN and verify that it matches hostname
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
			curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
				
			$json = curl_exec($curl);
			curl_close($curl);
			
			if ($json === false) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = __('Payment gateway is not available now (error 1). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			$post = json_decode($json, true);
			if (!$post) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = __('Payment gateway is not available now (error 2). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			if (isset($post['error'])) {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = ucfirst($post['error']['message']);
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			} else if ($post['status'] != 'new') {
				$return_data = array();
				$return_data['status'] = 'ERROR';
				$return_data['html'] = __('Payment gateway is not available now (error 3). Try again later.', 'paybox');
				echo $jsonp_callback.'('.json_encode($return_data).')';
				exit;
			}
			$return_data = array();
			$return_data['status'] = 'OK';
			$return_data['url'] = $post['url'];
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		} else {
			$return_data = array();
			$return_data['status'] = 'ERROR';
			$return_data['html'] = implode('<br />', $errors);
			echo $jsonp_callback.'('.json_encode($return_data).')';
			exit;
		}
		exit;
	}

	function remote_init() {
		global $wpdb;
		if (isset($_REQUEST['callback'])) {
			header("Content-type: text/javascript");
			$jsonp_callback = $_REQUEST['callback'];
		} else die("JSONP is not supported!");
		$return_data = array();
		$return_data['status'] = 'OK';
		if ($this->options['enable_stripe'] == 'on') {
			$return_data['resources']['stripe'] = 'on';
		} else {
			$return_data['resources']['stripe'] = 'off';
		}
		
		if (isset($_REQUEST['data'])) {
			$items = json_decode(base64_decode(trim(stripslashes($_REQUEST['data']))), true);
			if (sizeof($items) > 0) {
				foreach($items as $item) {
					if (!empty($item)) {
						$atts = array('id' => $item['id']);
						if (array_key_exists('return_url', $item)) $atts['return_url'] = $item['return_url'];
						if (array_key_exists('intro', $item)) $atts['title'] = $item['intro'];
						$return_data['forms'][$item['html_id']] = $this->shortcode_handler($atts);
					}
				}
			}
		}
		
		echo $jsonp_callback.'('.json_encode($return_data).')';
		exit;
	}

	function personal_data_exporters($_exporters) {
		$_exporters['paybox'] = array(
			'exporter_friendly_name' => __('Digital Paybox', 'paybox'),
			'callback' => array(&$this, 'personal_data_exporter')
		);
		return $_exporters;
	}
	
	function personal_data_exporter($_email_address, $_page = 1) {
		global $wpdb, $paybox;
		if (empty($_email_address)) {
			return array(
				'data' => array(),
				'done' => true
			);
		}
		$data_to_export = array();
		$rows = $wpdb->get_results("SELECT t1.*, t2.title AS file_title FROM ".$wpdb->prefix."dd_transactions t1 LEFT JOIN ".$wpdb->prefix."dd_files t2 ON t1.file_id = t2.id WHERE t1.payer_email = '".esc_sql($_email_address)."' OR t1.payer_name = '".esc_sql($_email_address)."' ORDER BY t1.created DESC", ARRAY_A);
		foreach ($rows as $row) {
			$data = array(
				'group_id' => 'paybox-transactions',
				'group_label' => __('Digital Paybox: Transactions', 'paybox'),
				'item_id' => 'paybox-transactions-'.$row['id']
			);
			if (!empty($row['file_title'])) $data['data'][] = array('name' => __('File', 'paybox'), 'value' => $row['file_title']);
			if (!empty($row['payer_name'])) $data['data'][] = array('name' => __('Payer name', 'paybox'), 'value' => $row['payer_name']);
			if (!empty($row['payer_email'])) $data['data'][] = array('name' => __('Payer email', 'paybox'), 'value' => $row['payer_email']);
			$data['data'][] = array('name' => __('Amount', 'paybox'), 'value' => ($row['currency'] == 'BTC' ? number_format($row['gross'], 8, ".", "") : number_format($row['gross'], 2, ".", "")).' '.$row['currency']);
			if (!empty($row['payment_status'])) $data['data'][] = array('name' => __('Status', 'paybox'), 'value' => $row['payment_status']);
			if (!empty($row['transaction_type'])) $data['data'][] = array('name' => __('Type', 'paybox'), 'value' => $row['transaction_type']);

			$details = explode("&", $row["details"]);
			foreach ($details as $param) {
				$temp = explode("=", $param, 2);
				if (sizeof($temp) > 1 && !empty($temp[1])) $data['data'][] = array('name' => 'Tx.'.$temp[0], 'value' => urldecode($temp[1]));
			}
			
			$data['data'][] = array('name' => __('Created', 'paybox'), 'value' => date("Y-m-d H:i", $row['created']));
			if ($row['deleted'] != 0) $data['data'][] = array('name' => __('Deleted', 'paybox'), 'value' => 'yes');
			$data_to_export[] = $data;
		}
		
		$rows = $wpdb->get_results("SELECT t1.*, t2.title AS file_title FROM ".$wpdb->prefix."dd_downloadlinks t1 LEFT JOIN ".$wpdb->prefix."dd_files t2 ON t2.id = t1.file_id WHERE t1.owner = '".$_email_address."' ORDER BY t1.created DESC", ARRAY_A);
		foreach ($rows as $row) {
			$data = array(
				'group_id' => 'paybox-links',
				'group_label' => __('Digital Paybox: Links', 'paybox'),
				'item_id' => 'paybox-links-'.$row['id']
			);
			if (!empty($row['file_title'])) $data['data'][] = array('name' => __('File', 'paybox'), 'value' => $row['file_title']);
			if (!empty($row['download_key'])) $data['data'][] = array('name' => __('Link', 'paybox'), 'value' => get_bloginfo('url').'/?paybox-key='.$row["download_key"]);
			if (!empty($row['owner'])) $data['data'][] = array('name' => __('Owner', 'paybox'), 'value' => $row['owner']);
			if (!empty($row['source'])) $data['data'][] = array('name' => __('Source', 'paybox'), 'value' => $row['source']);
			$data['data'][] = array('name' => __('Created', 'paybox'), 'value' => date("Y-m-d H:i", $row['created']));
			if ($row['deleted'] != 0) $data['data'][] = array('name' => __('Deleted', 'paybox'), 'value' => 'yes');
			$data_to_export[] = $data;
		}
	
		return array(
			'data' => $data_to_export,
			'done' => true
		);
	}
	
	function personal_data_erasers($_erasers) {
		$_erasers['paybox'] = array(
			'eraser_friendly_name' => __('Digital Paybox', 'paybox'),
			'callback' => array(&$this, 'personal_data_eraser')
		);
		return $_erasers;
	}

	function personal_data_eraser($_email_address, $_page = 1) {
		global $wpdb;
		if (empty($_email_address)) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}
		$tmp = $wpdb->get_row("SELECT COUNT(*) AS total FROM ".$wpdb->prefix."dd_transactions WHERE payer_email = '".esc_sql($_email_address)."' OR payer_name = '".esc_sql($_email_address)."'", ARRAY_A);
		$total = $tmp["total"];
		$wpdb->query("DELETE FROM ".$wpdb->prefix."dd_transactions WHERE payer_email = '".esc_sql($_email_address)."' OR payer_name = '".esc_sql($_email_address)."'");
		$tmp = $wpdb->get_row("SELECT COUNT(*) AS total FROM ".$wpdb->prefix."dd_downloadlinks WHERE owner = '".esc_sql($_email_address)."'", ARRAY_A);
		$total += $tmp["total"];
		$wpdb->query("DELETE FROM ".$wpdb->prefix."dd_downloadlinks WHERE owner = '".esc_sql($_email_address)."'");
		return array(
			'items_removed'  => $total,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}
	
	function generate_downloadlink($_fileid, $_owner, $_source) {
		global $wpdb;
		$file_details = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."dd_files WHERE id = '".intval($_fileid)."'", ARRAY_A);
		if (intval($file_details["id"]) == 0) return false;
		$symbols = '123456789abcdefghijklmnopqrstuvwxyz';
		$download_key = "";
		for ($i=0; $i<16; $i++) {
			$download_key .= $symbols[rand(0, strlen($symbols)-1)];
		}
		$sql = "INSERT INTO ".$wpdb->prefix."dd_downloadlinks (
			file_id, download_key, owner, source, created) VALUES (
			'".$_fileid."',
			'".$download_key."',
			'".esc_sql($_owner)."',
			'".$_source."',
			'".time()."'
		)";
		$wpdb->query($sql);
		return defined('UAP_CORE') ? admin_url('do.php').'?paybox-key='.$download_key : get_bloginfo("url").'/?paybox-key='.$download_key;
	}

	function admin_modal_html() {
		return '
<div class="paybox-modal-overlay"></div>
<div class="paybox-modal">
	<div class="paybox-modal-content">
		<div class="paybox-modal-message"></div>
		<div class="paybox-modal-buttons">
			<a class="paybox-modal-button" id="paybox-modal-button-ok" href="#" onclick="return false;"><i class="paybox-fa paybox-fa-ok"></i><label></label></a>
			<a class="paybox-modal-button" id="paybox-modal-button-cancel" href="#" onclick="return false;"><i class="paybox-fa paybox-fa-cancel"></i><label></label></a>
		</div>
	</div>
</div>';
	}

	function page_switcher ($_urlbase, $_currentpage, $_totalpages) {
		$pageswitcher = "";
		if ($_totalpages > 1) {
			$pageswitcher = '<div class="tablenav bottom"><div class="tablenav-pages">'.__('Pages:', 'paybox').' <span class="pagiation-links">';
			if (strpos($_urlbase,"?") !== false) $_urlbase .= "&amp;";
			else $_urlbase .= "?";
			if ($_currentpage == 1) $pageswitcher .= "<a class='page disabled'>1</a> ";
			else $pageswitcher .= " <a class='page' href='".$_urlbase."p=1'>1</a> ";

			$start = max($_currentpage-3, 2);
			$end = min(max($_currentpage+3,$start+6), $_totalpages-1);
			$start = max(min($start,$end-6), 2);
			if ($start > 2) $pageswitcher .= " <b>...</b> ";
			for ($i=$start; $i<=$end; $i++) {
				if ($_currentpage == $i) $pageswitcher .= " <a class='page disabled'>".$i."</a> ";
				else $pageswitcher .= " <a class='page' href='".$_urlbase."p=".$i."'>".$i."</a> ";
			}
			if ($end < $_totalpages-1) $pageswitcher .= " <b>...</b> ";

			if ($_currentpage == $_totalpages) $pageswitcher .= " <a class='page disabled'>".$_totalpages."</a> ";
			else $pageswitcher .= " <a class='page' href='".$_urlbase."p=".$_totalpages."'>".$_totalpages."</a> ";
			$pageswitcher .= "</span></div></div>";
		}
		return $pageswitcher;
	}
	
	function get_filename($_path, $_filename) {
		$filename = preg_replace('/[^a-zA-Z0-9\s\-\.\_]/', ' ', $_filename);
		$filename = preg_replace('/(\s\s)+/', ' ', $filename);
		$filename = trim($filename);
		$filename = preg_replace('/\s+/', '-', $filename);
		$filename = preg_replace('/\-+/', '-', $filename);
		if (strlen($filename) == 0) $filename = "file";
		else if ($filename[0] == ".") $filename = "file".$filename;
		while (file_exists($_path.$filename)) {
			$pos = strrpos($filename, ".");
			if ($pos !== false) {
				$ext = substr($filename, $pos);
				$filename = substr($filename, 0, $pos);
			} else {
				$ext = "";
			}
			$pos = strrpos($filename, "-");
			if ($pos !== false) {
				$suffix = substr($filename, $pos+1);
				if (is_numeric($suffix)) {
					$suffix++;
					$filename = substr($filename, 0, $pos)."-".$suffix.$ext;
				} else {
					$filename = $filename."-1".$ext;
				}
			} else {
				$filename = $filename."-1".$ext;
			}
		}
		return $filename;
	}

	function period_to_string($period) {
		$period_str = "";
		$days = floor($period/(24*3600));
		$period -= $days*24*3600;
		$hours = floor($period/3600);
		$period -= $hours*3600;
		$minutes = floor($period/60);
		if ($days > 1) $period_str = $days.' '.__('days', 'paybox').', ';
		else if ($days == 1) $period_str = $days.' '.__('day', 'paybox').', ';
		if ($hours > 1) $period_str .= $hours.' '.__('hours', 'paybox').', ';
		else if ($hours == 1) $period_str .= $hours.' '.__('hour', 'paybox').', ';
		else if (!empty($period_str)) $period_str .= '0 '.__('hours', 'paybox').', ';
		if ($minutes > 1) $period_str .= $minutes.' '.__('minutes', 'paybox');
		else if ($minutes == 1) $period_str .= $minutes.' '.__('minute', 'paybox');
		else $period_str .= '0 '.__('minutes', 'paybox');
		return $period_str;
	}
	
	function random_string($_length = 16) {
		$symbols = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$str_id = "";
		for ($i=0; $i<$_length; $i++) {
			$str_id .= $symbols[rand(0, strlen($symbols)-1)];
		}
		return $str_id;
	}
}
$paybox = new paybox_class();
?>