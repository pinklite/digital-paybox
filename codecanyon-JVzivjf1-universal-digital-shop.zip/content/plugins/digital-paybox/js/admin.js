var paybox_saving = false;
function paybox_switch_gdpr() {
	if (jQuery("#paybox_gdpr_enable").is(":checked")) {
		jQuery(".paybox-gdpr-depend").fadeIn(200);
	} else {
		jQuery(".paybox-gdpr-depend").fadeOut(200);
	}
}
function paybox_save_settings(_button) {
	if (paybox_saving) return false;
	paybox_saving = true;
	var button_object = _button;
	jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-spinner paybox-fa-spin");
	jQuery(button_object).addClass("paybox-button-disabled");
	jQuery(".paybox-message").slideUp(350);
	jQuery.ajax({
		type	: "POST",
		url		: paybox_ajax_handler, 
		data	: jQuery(".paybox-form").serialize(),
		success	: function(return_data) {
			jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-ok");
			jQuery(button_object).removeClass("paybox-button-disabled");
			var data;
			try {
				var data = jQuery.parseJSON(return_data);
				if (data.status == "OK") {
					paybox_global_message_show('success', data.message);
				} else if (data.status == "ERROR") {
					jQuery(".paybox-message").html(data.message);
					jQuery(".paybox-message").slideDown(350);
				} else {
					jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
					jQuery(".paybox-message").slideDown(350);
				}
			} catch(error) {
				jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
				jQuery(".paybox-message").slideDown(350);
			}
			paybox_saving = false;
		},
		error	: function(XMLHttpRequest, textStatus, errorThrown) {
			jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-ok");
			jQuery(button_object).removeClass("paybox-button-disabled");
			jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
			jQuery(".paybox-message").slideDown(350);
			paybox_saving = false;
		}
	});
	return false;
}
function paybox_create_link(_button) {
	if (paybox_saving) return false;
	paybox_saving = true;
	var button_object = _button;
	jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-spinner paybox-fa-spin");
	jQuery(button_object).addClass("paybox-button-disabled");
	jQuery(".paybox-message").slideUp(350);
	jQuery.ajax({
		type	: "POST",
		url		: paybox_ajax_handler, 
		data	: jQuery(".paybox-form").serialize(),
		success	: function(return_data) {
			jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-ok");
			jQuery(button_object).removeClass("paybox-button-disabled");
			var data;
			try {
				var data = jQuery.parseJSON(return_data);
				if (data.status == "OK") {
					jQuery("#paybox-id").val(data.id);
					paybox_global_message_show('success', data.message);
					location.href = data.redirect_url;
				} else if (data.status == "ERROR") {
					jQuery(".paybox-message").html(data.message);
					jQuery(".paybox-message").slideDown(350);
				} else {
					jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
					jQuery(".paybox-message").slideDown(350);
				}
			} catch(error) {
				jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
				jQuery(".paybox-message").slideDown(350);
			}
			paybox_saving = false;
		},
		error	: function(XMLHttpRequest, textStatus, errorThrown) {
			jQuery(button_object).find("i").attr("class", "paybox-fa paybox-fa-ok");
			jQuery(button_object).removeClass("paybox-button-disabled");
			jQuery(".paybox-message").html("Something went wrong. We got unexpected server response.");
			jQuery(".paybox-message").slideDown(350);
			paybox_saving = false;
		}
	});
	return false;
}
var paybox_global_message_timer;
function paybox_global_message_show(_type, _message) {
	clearTimeout(paybox_global_message_timer);
	jQuery("#paybox-global-message").fadeOut(300, function() {
		jQuery("#paybox-global-message").attr("class", "");
		jQuery("#paybox-global-message").addClass("paybox-global-message-"+_type).html(_message);
		jQuery("#paybox-global-message").fadeIn(300);
		paybox_global_message_timer = setTimeout(function(){jQuery("#paybox-global-message").fadeOut(300);}, 5000);
	});
}

/* Modal Popup - begin */
var paybox_modal_buttons_disable = false;
function paybox_modal_open(_settings) {
	var settings = {
		width: 				480,
		height:				180,
		ok_label:			'Yes',
		cancel_label:		'Cancel',
		message:			'Do you really want to continue?',
		ok_function:		function() {paybox_modal_close();},
		cancel_function:	function() {paybox_modal_close();}
	}
	var objects = [settings, _settings],
    settings = objects.reduce(function (r, o) {
		Object.keys(o).forEach(function (k) {
			r[k] = o[k];
		});
		return r;
    }, {});
	
	paybox_modal_buttons_disable = false;
	jQuery(".paybox-modal-message").html(settings.message);
	jQuery(".paybox-modal").width(settings.width);
	jQuery(".paybox-modal").height(settings.height);
	jQuery(".paybox-modal-content").width(settings.width);
	jQuery(".paybox-modal-content").height(settings.height);
	jQuery(".paybox-modal-button").unbind("click");
	jQuery(".paybox-modal-button").removeClass("paybox-modal-button-disabled");
	jQuery("#paybox-modal-button-ok").find("label").html(settings.ok_label);
	jQuery("#paybox-modal-button-cancel").find("label").html(settings.cancel_label);
	jQuery("#paybox-modal-button-ok").bind("click", function(e){
		e.preventDefault();
		if (!paybox_modal_buttons_disable && typeof settings.ok_function == "function") {
			settings.ok_function();
		}
	});
	jQuery("#paybox-modal-button-cancel").bind("click", function(e){
		e.preventDefault();
		if (!paybox_modal_buttons_disable && typeof settings.cancel_function == "function") {
			settings.cancel_function();
		}
	});
	jQuery(".paybox-modal-overlay").fadeIn(300);
	jQuery(".paybox-modal").css({
		'top': 					'50%',
		'transform': 			'translate(-50%, -50%) scale(1)',
		'-webkit-transform': 	'translate(-50%, -50%) scale(1)'
	});
}
function paybox_modal_close() {
	jQuery(".paybox-modal-overlay").fadeOut(300);
	jQuery(".paybox-modal").css({
		'transform': 			'translate(-50%, -50%) scale(0)',
		'-webkit-transform': 	'translate(-50%, -50%) scale(0)'
	});
	setTimeout(function(){jQuery(".paybox-modal").css("top", "-3000px")}, 300);
}
/* Modal Popup - end */
function paybox_confirm_redirect(_object, _action) {
	var message, button_label;
	if (_action == "delete") {
		message = 'Please confirm that you want to delete the item.';
		button_label = 'Delete';
	} else if (_action == "delete-all") {
		message = 'Please confirm that you want to delete all items.';
		button_label = 'Delete';
	} else {
		message = 'Please confirm that you want to perform this action.';
		button_label = 'Do';
	}
	paybox_modal_open({
		message:		message,
		ok_label:		button_label,
		ok_function:	function(e) {
			paybox_modal_close();
			location.href = jQuery(_object).attr("href");
		}
	});
	return false;
}

function paybox_admin_popup_resize() {
	if (paybox_record_active) {
		var popup_height = 2*parseInt((jQuery(window).height() - 100)/2, 10);
		var popup_width = Math.min(Math.max(2*parseInt((jQuery(window).width() - 300)/2, 10), 640), 1080);
		jQuery("#paybox-admin-popup").height(popup_height);
		jQuery("#paybox-admin-popup").width(popup_width);
		jQuery("#paybox-admin-popup .paybox-admin-popup-inner").height(popup_height);
		jQuery("#paybox-admin-popup .paybox-admin-popup-content").height(popup_height - 52);
	}
}
function paybox_admin_popup_ready() {
	paybox_admin_popup_resize();
	jQuery(window).resize(function() {
		paybox_admin_popup_resize();
	});
}

var paybox_record_active = null;
function paybox_admin_popup_open(_object) {
	var action = jQuery(_object).attr("data-action");
	if (typeof action == typeof undefined) return false;
	jQuery("#paybox-admin-popup .paybox-admin-popup-content-form").html("");
	var window_height = 2*parseInt((jQuery(window).height() - 100)/2, 10);
	var window_width = Math.min(Math.max(2*parseInt((jQuery(window).width() - 300)/2, 10), 640), 1080);
	jQuery("#paybox-admin-popup").height(window_height);
	jQuery("#paybox-admin-popup").width(window_width);
	jQuery("#paybox-admin-popup .paybox-admin-popup-inner").height(window_height);
	jQuery("#paybox-admin-popup .paybox-admin-popup-content").height(window_height - 52);
	jQuery("#paybox-admin-popup-overlay").fadeIn(300);
	jQuery("#paybox-admin-popup").css({
		'top': 					'50%',
		'transform': 			'translate(-50%, -50%) scale(1)',
		'-webkit-transform': 	'translate(-50%, -50%) scale(1)'
	});
	var title = jQuery(_object).attr("data-title");
	if (typeof title != typeof undefined) jQuery("#paybox-admin-popup .paybox-admin-popup-title h3 label").html(title);
	var subtitle = jQuery(_object).attr("data-subtitle");
	if (typeof subtitle != typeof undefined) jQuery("#paybox-admin-popup .paybox-admin-popup-title h3 span").html(subtitle);
	jQuery("#paybox-admin-popup .paybox-admin-popup-loading").show();
	paybox_record_active = jQuery(_object).attr("data-id");
	var post_data = {"action" : action, "id" : paybox_record_active};
	jQuery.ajax({
		type	: "POST",
		url		: paybox_ajax_handler, 
		data	: post_data,
		success	: function(return_data) {
			try {
				var data;
				if (typeof return_data == 'object') data = return_data;
				else data = jQuery.parseJSON(return_data);
				if (data.status == "OK") {
					jQuery("#paybox-admin-popup .paybox-admin-popup-content-form").html(data.html);
					jQuery("#paybox-admin-popup .paybox-admin-popup-loading").hide();
				} else if (data.status == "ERROR") {
					paybox_admin_popup_close();
					paybox_global_message_show("danger", data.message);
				} else {
					paybox_admin_popup_close();
					paybox_global_message_show("danger", paybox_esc_html__("Something went wrong. We got unexpected server response."));
				}
			} catch(error) {
				paybox_admin_popup_close();
				paybox_global_message_show("danger", paybox_esc_html__("Something went wrong. We got unexpected server response."));
			}
		},
		error	: function(XMLHttpRequest, textStatus, errorThrown) {
			paybox_admin_popup_close();
			paybox_global_message_show("danger", paybox_esc_html__("Something went wrong. We got unexpected server response."));
		}
	});

	return false;
}
function paybox_admin_popup_close() {
	jQuery("#paybox-admin-popup-overlay").fadeOut(300);
	jQuery("#paybox-admin-popup").css({
		'transform': 			'translate(-50%, -50%) scale(0)',
		'-webkit-transform': 	'translate(-50%, -50%) scale(0)'
	});
	paybox_record_active = null;
	setTimeout(function(){jQuery("#paybox-admin-popup .paybox-admin-popup-content-form").html(""); jQuery("#paybox-admin-popup").css("top", "-3000px")}, 1000);
	return false;
}
function paybox_esc_html__(_string) {
	var string;
	if (typeof paybox_translations == typeof {} && paybox_translations.hasOwnProperty(_string)) {
		string = paybox_translations[_string];
		if (string.length == 0) string = _string;
	} else string = _string;
	return paybox_escape_html(string);
}
function paybox_escape_html(_text) {
	if (!_text) return "";
	var map = {
		'&': '&amp;',
		'<': '&lt;',
		'>': '&gt;',
		'"': '&quot;',
		"'": '&#039;'
	};
	return _text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function paybox_utf8encode(string) {
	string = string.replace(/\x0d\x0a/g, "\x0a");
	var output = "";
	for (var n = 0; n < string.length; n++) {
		var c = string.charCodeAt(n);
		if (c < 128) {
			output += String.fromCharCode(c);
		} else if ((c > 127) && (c < 2048)) {
			output += String.fromCharCode((c >> 6) | 192);
			output += String.fromCharCode((c & 63) | 128);
		} else {
			output += String.fromCharCode((c >> 12) | 224);
			output += String.fromCharCode(((c >> 6) & 63) | 128);
			output += String.fromCharCode((c & 63) | 128);
		}
	}
	return output;
}
function paybox_encode64(input) {
	var keyString = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
	var output = "";
	var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
	var i = 0;
	input = paybox_utf8encode(input);
	while (i < input.length) {
		chr1 = input.charCodeAt(i++);
		chr2 = input.charCodeAt(i++);
		chr3 = input.charCodeAt(i++);
		enc1 = chr1 >> 2;
		enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
		enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
		enc4 = chr3 & 63;
		if (isNaN(chr2)) {
			enc3 = enc4 = 64;
		} else if (isNaN(chr3)) {
			enc4 = 64;
		}
		output = output + keyString.charAt(enc1) + keyString.charAt(enc2) + keyString.charAt(enc3) + keyString.charAt(enc4);
	}
	return output;
}
function paybox_utf8decode(input) {
	var string = "";
	var i = 0;
	var c = c1 = c2 = 0;
	while ( i < input.length ) {
		c = input.charCodeAt(i);
		if (c < 128) {
			string += String.fromCharCode(c);
			i++;
		} else if ((c > 191) && (c < 224)) {
			c2 = input.charCodeAt(i+1);
			string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
			i += 2;
		} else {
			c2 = input.charCodeAt(i+1);
			c3 = input.charCodeAt(i+2);
			string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
			i += 3;
		}
	}
	return string;
}
function paybox_decode64(input) {
	var keyString = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
	var output = "";
	var chr1, chr2, chr3;
	var enc1, enc2, enc3, enc4;
	var i = 0;
	input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
	while (i < input.length) {
		enc1 = keyString.indexOf(input.charAt(i++));
		enc2 = keyString.indexOf(input.charAt(i++));
		enc3 = keyString.indexOf(input.charAt(i++));
		enc4 = keyString.indexOf(input.charAt(i++));
		chr1 = (enc1 << 2) | (enc2 >> 4);
		chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
		chr3 = ((enc3 & 3) << 6) | enc4;
		output = output + String.fromCharCode(chr1);
		if (enc3 != 64) {
			output = output + String.fromCharCode(chr2);
		}
		if (enc4 != 64) {
			output = output + String.fromCharCode(chr3);
		}
	}
	output = paybox_utf8decode(output);
	return output;
}
